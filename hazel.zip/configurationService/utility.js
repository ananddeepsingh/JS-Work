﻿"use strict";

var fs = require('fs-extra');

var responseMessage = {
    success: {
        message: 'Ok'
    },
    error: {
        message: 'Error'
    }
};

exports.readUserConfigFile = function (userName) {
    try {
        var str = fs.readFileSync(__dirname + '/data/' + userName + '/config.json', 'utf8');
        return JSON.parse(str);
    } catch (ex) {
        console.log('Error in reading file.');
        return null;
    }
}

exports.writeUserConfigFile = function (userName, settings) {
    if (!fs.existsSync(__dirname + '/data/' + userName + '/config.json')) {
        fs.mkdirSync(__dirname + '/data/' + userName)
    }
    fs.writeFileSync(__dirname + '/data/' + userName + '/config.json', JSON.stringify(settings, null, 4), 'utf8');
}

exports.readConfigFile = function () {
    try {
        var str = fs.readFileSync(__dirname + '/data/' + 'config.json', 'utf8');
        return JSON.parse(str);
    } catch (ex) {
        console.log('Error in reading file.');
        return {};
    }
}

exports.writeConfigFile = function (settings) {
    fs.writeFileSync(__dirname + '/data/' + 'config.json', JSON.stringify(settings, null, 4), 'utf8');
}

exports.getSuccessResponseMessage = function () {
    
    return responseMessage.success;
}

exports.getErrorResponseMessage = function () {
    
    return responseMessage.error;
}

exports.sort_by = function (field, reverse) {
    
    var key = function (x) { return x[field] };
    
    reverse = !reverse ? 1 : -1;
    
    return function (a, b) {
        
        return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
    }
}