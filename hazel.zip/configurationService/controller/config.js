﻿"use strict";

var util = require('../utility');
var router = require('express').Router();
var grep = require('grep-from-array');

//router.use(crossOriginHandler);

router.post('/api/config/layout', getAllLayouts);

router.post('/api/config/saveConfig', saveConfig);
router.delete('/api/config/deleteConfig', deleteConfig);
router.post('/api/config/getConfig', getConfig);
router.post('/api/config/getSettings', getSettings);

router.delete('/api/config/deleteConfigQuery', deleteConfigByQueryParameters);

function getAllLayouts(req, res, next){
    
    var userDetail = req.body.userDetail;
    var userName = userDetail.userName;

    var settings = getConfigSettings(userName);

    var arr = [];
    settings.layouts = settings.layouts || [];
    for (var i = 0; i < settings.layouts.length; ++i) {
        arr.push(settings.layouts[i].name);
    }
    
    res.json(arr);    
}

function saveConfig(req, res, next) {
    
    try {
        var userDetail = req.body.userDetail;
        var data = req.body.data;
        var userName = (typeof userDetail != 'undefined') ? userDetail.userName : null;
        var settings;
        if (typeof userName === 'undefined' || userName === null) {
            settings = util.readConfigFile();
        }
        else {
            settings = util.readUserConfigFile(userName);
            if (settings === null) {
                settings = {};
            }
        }
        
        for (var elementIndex = 0; elementIndex < data.length; elementIndex += 1) {
            
            var configElement = data[elementIndex].name;
            var valueArray = data[elementIndex].value;
            
            settings[configElement] = settings[configElement] || [];
            
            for (var valueIndex = 0; valueIndex < valueArray.length; valueIndex += 1) {
                
                var value = valueArray[valueIndex].value;
                var name = valueArray[valueIndex].name;
                
                //remove prev layout with same name
                deleteElement(settings, configElement, name);
                
                settings[configElement].push({
                    name: name,
                    value: value
                });
            }
        }
        
        if (typeof userName === 'undefined' || userName === null) {
            util.writeConfigFile(settings);
        }
        else {
            util.writeUserConfigFile(userName , settings);
        }
        
        res.json(util.getSuccessResponseMessage());
    }
    catch (xe) {
        
        console.log('SaveConfig-->Error in saving configuration. Error:' + xe);
        res.status(500).json({ message: xe });
    }
}

function deleteConfig(req, res, next) {
    
    var userDetail = req.body.userDetail;
    var data = req.body.data;
    var userName = (typeof userDetail != 'undefined') ? userDetail.userName : null;
    var settings;
    if (typeof userName === 'undefined' || userName === null) {
        settings = util.readConfigFile();
    }
    else {
        settings = util.readUserConfigFile(userName);
        if (settings === null) {
            settings = {};
        }
    }
    
    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;
    
    settings[configElement] = settings[configElement] || [];
    try {
        
        deleteElement(settings, configElement, name);
                
        if (typeof userName === 'undefined' || userName === null) {
            util.writeConfigFile(settings);
        }
        else {
            util.writeUserConfigFile(userName, settings);
        }
        
        res.json({ message: 'Success' });
    } catch (ex) {
        res.status(500);
        res.json({ message: 'Error in deleting config' });
    }

}

function deleteElement(settings, configElement, name) {
    for (var i = 0; i < settings[configElement].length; ++i) {
        if (settings[configElement][i].name === name) {
            return settings[configElement].splice(i, 1);            
        }
    }
}

function getConfig(req, res, next) {
    
    var userDetail = req.body.userDetail;
    var userName = (typeof userDetail != 'undefined') ? userDetail.userName : null;
    
    var settings = getConfigSettings(userName);
    var config;
    var data = req.body.data;
    
    config = getElementOverride(settings, req);
    
    if (config != null) {
        res.json(config);
    }
    else {
        //res.status(400);
        res.json(null);
    }
}

function getConfigSettings(userName) {
    
    var rootSettings = util.readConfigFile();

    if (typeof userName === 'undefined' || userName === null) {
        return rootSettings;
    }

    var userSettings = util.readUserConfigFile(userName);

    for (var property in userSettings) {

        var values = userSettings[property];

        for (var index = 0; index < values.length; index += 1) {

            var currentValue = values[index];
            rootSettings[property] = rootSettings[property] || [];
            var result = grep(rootSettings[property], function (val) { return val.name == currentValue.name; })
            if (result.length > 0) {

                for (var i = 0; i < rootSettings[property].length; ++i) {
                    if (rootSettings[property][i].name === currentValue.name) {
                        rootSettings[property].splice(i, 1);
                        break;
                    }
                }
            }
            rootSettings[property].push(currentValue);
        }
    }

    return rootSettings;
}

function getElement(settings, req) {
        
    var data = req.body.data;
    
    var configElement = data.configElement;
    var name = data.name;

    var returnConfigElement = null;
    
    settings[configElement] = settings[configElement] || [];
    
    if (typeof name === 'undefined' || name === null || name === '') {
        returnConfigElement = settings[configElement].sort(util.sort_by('name', false));
    }
    else {
        for (var i = 0; i < settings[configElement].length; ++i) {
            if (settings[configElement][i].name === name) {
                returnConfigElement = settings[configElement][i].value;
                break;
            }
        }
    }
    
    return returnConfigElement;
}

function getSettings(req, res, next) {
    
    var userDetail = req.body.userDetail;   
    
    var userName = userDetail.userName;

    var settings = getConfigSettings(userName);
    
    res.json(settings);
}

function deleteConfigByQueryParameters(req, res, next) {
    
    var settings = util.readConfigFile();
    
    var data = req.query;
    
    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;
    
    settings[configElement] = settings[configElement] || [];
    try {
        
        deleteElement(settings, configElement, name);
        util.writeConfigFile(settings);
        
        res.json({ message: 'Success' });
    } catch (ex) {
        res.status(500);
        res.json({ message: 'Error in deleting config' });
    }

}

function getElementOverride(settings, req) {
    
    var data = req.body.data;
    var configElements = [];
    
    for (var elementIndex = 0; elementIndex < data.length; elementIndex += 1) {
        
        var current = data[elementIndex];
        var configElement = current.configElement;
        var name = current.name;
        
        var element = { name: configElement, value: [] };
        
        if (typeof name === 'undefined' || name.length <= 0) {

            settings[configElement] = settings[configElement] || [];

            for (var i = 0; i < settings[configElement].length; ++i) {
                element.value.push(settings[configElement][i]);
            }
        }
        else {
            
            for (var nameIndex = 0; nameIndex < name.length; nameIndex += 1) {
                
                var currentName = name[nameIndex];
                
                settings[configElement] = settings[configElement] || [];
                
                for (var i = 0; i < settings[configElement].length; ++i) {
                    if (settings[configElement][i].name === currentName) {
                        element.value.push(settings[configElement][i]);
                        
                    }
                }
            
            }
        }
        
        configElements.push(element);
    }
    
    return configElements;
}


module.exports = router;