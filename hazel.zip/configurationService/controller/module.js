﻿"use strict";

var router = require('express').Router();

var moduleDir = global.packageData.moduleRegistryDirPath;
var multer = require('multer');
var upload = multer({
    dest: moduleDir
});
var fs = require('fs-extra');
var fStream = require('fstream');
var unzip = require('unzip');
var util = require('../utility');

router.post('/register', upload.single('fileToUpload'), registerModule);
router.get('/register', getAllRegisteredModules);
router.post('/updatemetadata', updateModuleMetadata);
router.delete('/updatemetadata', deleteModuleMetadata);

function registerModule(req, res, next) {
    
    var module = JSON.parse(req.body["packageData"]);
    var moduleName = module.name;
    console.log("Module name :- " + moduleName);
    var modulePath = moduleDir + '/' + moduleName;
    
    var writePackageJson = function (path, obj) {
        fs.writeFileSync(path + '/package.json', JSON.stringify(obj, null, 4), 'utf8');
    };
    
    // empty dir if file is recieved
    var func = req.file ? fs.emptyDir : fs.ensureDir;
    func(modulePath, function (err) {
        if (err) {
            console.log("Error occurred while creating folder. :-  " + err);
            res.json({ message: "Error occurred while creating folder." });
        } else {            
            if (req.file) {
                var readStream = fs.createReadStream(req.file.path);
                var writeStream = fStream.Writer(modulePath);
                
                readStream
                .pipe(unzip.Parse())
                .pipe(writeStream)
                .on('close', function (close) {
                    console.log("unzip completed.");
                    //delete zip file
                    fs.unlinkSync(req.file.path);
                    
                    // write package.json
                    writePackageJson(modulePath, module);
                    
                    res.json({ message: "upload successful" });
                })
                .on('err', function (close) {
                    console.log("error");
                    //delete zip file
                    fs.unlinkSync(req.file.path);
                    
                    res.json({ message: "upload failed" });
                });
            } else {
                // write package.json even wen file is not being uploaded
                writePackageJson(modulePath, module);
                res.json({ message: "config package updated" });
            }
                                
        }
    });
}



function getAllRegisteredModules(req, res, next){

    var data = [];

    // read all folders of the /data/modules
    var folders = fs.readdirSync(moduleDir);

    // read name from package.json
    for (var i = 0; i < folders.length; ++i) {
        try {
            var packageData = JSON.parse(
                fs.readFileSync(moduleDir + '/' + folders[i] + '/package.json', 'utf8'));
            
            packageData.path = packageData.name + '/' + packageData.main;
            data.push(packageData);
        } catch (ex) {
            // package.json was not found
        }
    }
    
    data.sort(util.sort_by('name', false));
    // contruct path from modules/main.js

    res.json(data);
}


function updateModuleMetadata(req, res, next){
    var settings = util.readConfigFile();
    
    settings.moduleConfig = settings.moduleConfig || [];
    settings.moduleMappingConfigList = settings.moduleMappingConfigList || [];
    
    // fail if published-name exists
    if (moduleConfigExists(settings, req.body.moduleConfig)) {
        var moduleName = req.body.moduleConfig.name;
        for (var i = 0; i < settings.moduleConfig.length; ++i) {
            if (moduleName === settings.moduleConfig[i].name) {
                settings.moduleConfig.splice(i , 1);
                break;
            }
        }
        for (var i = 0; i < settings.moduleMappingConfigList.length; ++i) {
            if (moduleName === settings.moduleMappingConfigList[i].PublishedName) {
                settings.moduleMappingConfigList.splice(i , 1);
                break;
            }
        }
    }

    settings.moduleConfig.push(req.body.moduleConfig);
    settings.moduleMappingConfigList.push(req.body.moduleMappingConfigList);

    util.writeConfigFile(settings);
    res.json({data: 'success'});
}


function moduleConfigExists(settings, module) {
    for (var i = 0; i < settings.moduleConfig.length; ++i) {
        if (settings.moduleConfig[i].name === module.name) {
            return true;
        }
    }
    return false;
}

function deleteModuleMetadata(req, res, next){
    var settings = util.readConfigFile();
    
    settings.moduleConfig = settings.moduleConfig || [];
    settings.moduleMappingConfigList = settings.moduleMappingConfigList || [];
    
    try {
        var moduleName = req.body.PublishedName;

        for (var i = 0; i < settings.moduleConfig.length; ++i) {
            if (moduleName === settings.moduleConfig[i].name) {
                settings.moduleConfig.splice(i , 1);
                break;
            }
        }
        for (var i = 0; i < settings.moduleMappingConfigList.length; ++i) {
            if (moduleName === settings.moduleMappingConfigList[i].PublishedName) {
                settings.moduleMappingConfigList.splice(i , 1);
                break;
            }
        }
        
        util.writeConfigFile(settings);
        res.json({message: 'sucessfully deleted'});
    } catch (ex) {
        res.status(500);
        res.json({ message: 'not sucessful ' + ex });
    }
    
}

module.exports = router;