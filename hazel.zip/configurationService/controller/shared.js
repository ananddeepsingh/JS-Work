﻿"use strict";

var router = require('express').Router();

var multer = require('multer');
var upload = multer({ dest: global.packageData.sharedDirPath });
var util = require('../utility');
var fs = require('fs-extra');

router.post('/', upload.single('file'), updateSharedResource);
router.get('/:name', getSharedResource);
router.get('/', getSharedResource);


function getSharedResource(req, res, next){
    var settings = util.readConfigFile();
    
    settings.sharedConfig = settings.sharedConfig || [];

    // if no name supplied. return all shared module config list
    if (!req.params.name) {
        res.json(settings.sharedConfig.sort(util.sort_by('name', false)));
        return;
    }

    for (var i = 0; i < settings.sharedConfig.length; ++i) {
        if (settings.sharedConfig[i].name === req.params.name) {
            res.json(settings.sharedConfig[i]);
        }
    }
    res.end();
}

function updateSharedResource(req, res, next) {
    
    var settings = util.readConfigFile();
    
    settings.sharedConfig = settings.sharedConfig || [];
    
    if (!req.file) {
        res.status(500).json({ message: 'shared file missing' });
        return;
    }

    deleteIfExists(req.body.name, settings.sharedConfig);

    settings.sharedConfig.push({
        filename: '/shared/' + req.file.filename,
        name: req.body.name,
        version: req.body.version,
        keyword: req.body.keyword
    })
    
    util.writeConfigFile(settings);
    res.json({ message: "file is updated successfully." });
}


function deleteIfExists(name, config){
    for (var i = 0; i < config.length; i+=1) {
        if (config[i].name === name) {
            
            // delete file
            var file = config[i].filename.substring('/shared/'.length);
            fs.removeSync(global.packageData.sharedDirPath +'/' + file);           

            config.splice(i, 1);
        }
    }
}

module.exports = router;