"use strict";

var express = require('express');
var app = express();
var path = require('path');
var http = require('http').createServer(app);

// initilize object to setup the global settings
global.packageData = {};

var nodeSettings = require('./nodeSettings.json');
global.packageData.environments = Object.keys(nodeSettings.settings);
var applicationEnvironment = global.packageData.applicationEnvironment = nodeSettings.applicationEnvironment; // get env of the appEnv
//get node settings
for (var current in nodeSettings.settings[applicationEnvironment]) {
    
    global.packageData[current] = nodeSettings.settings[applicationEnvironment][current];
}

//get application settings
var applicationSettings = require('./applicationSettings.json');
for (var current in applicationSettings.settings[applicationEnvironment]) {
    
    global.packageData[current] = applicationSettings.settings[applicationEnvironment][current];
}

// setup NTLM
/*var ntlm = require('express-ntlm');
app.use(ntlm({
    domain: global.packageData.domain,
    domaincontroller: global.packageData.domaincontroller,
    debug: function (){
        //var args = Array.prototype.slice.apply(arguments);
        //console.log.apply(null, args);
    }
}));*/

app.all('*', function (request, response, next) {
    //response.end(JSON.stringify(request.ntlm)); // {"DomainName":"MYDOMAIN","UserName":"MYUSER","Workstation":"MYWORKSTATION"}    
    request.ntlm = {
        UserName: 'yogesh.pant',
        DomainName: 'Iris',
        Workstation: 'Workstation'
    };
next();
});


// install body-parser
var bodyParser = require('body-parser');
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// initialize controllers
app.use('/api/datagateway', require('./controller/dataGateway'));
app.use('/api/usage', require('./controller/usage'));
app.use('/', require('./controller/page'));
app.use('/api/promotelement', require('./controller/promotion'));
app.use('/api/stream', require('./controller/stream'));

// setup direct files for use
app.use(express.static('public'));
app.use(express.static('data'));
app.use(express.static('dist'));

// set ejs view engine
app.set('view engine', 'ejs');

// setup sockets
var io = require('socket.io').listen(http);

io.on('connection', function (socket) {
    console.log('user connected');
    socket.on('logMessage', function (msg) {
        
        console.log('Socket Listner:');
        console.dir(msg);
        //socketcontroller.logMessage(filePath, msg)
    });
    socket.on('disconnect', function () {
        console.log('user disconnected');
    });
});

// start the server
http.listen(global.packageData.httpPort, function (err) {
    if (!err) {
        console.log("Server is started on port " + global.packageData.httpPort);    
    }
    else {
        console.log("Server failed to start. Error["+err+"].");
    }
    
});
