﻿"use strict";

var router = require('express').Router();
var util = require('../utility');

var responseMessage = {
    message:'',
    saveDataSourceMessage : 'DataSource configuration saved successfully.',
    deleteDataSourceMessage: 'DataSource deleted successfully.'
};

router.get('/getdatasource', getAllDataSources);

function getAllDataSources(req, res, next) {

    var settings = util.readConfigFile();
    
    if (typeof settings.dataSourceList === 'undefined') {
        settings.dataSourceList = [];
    }
    
    res.json(settings.dataSourceList);
}

module.exports = router;