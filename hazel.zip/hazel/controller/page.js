﻿"use strict";

var util = require('../utility');
var router = require('express').Router();
var grep = require('grep-from-array');

router.get('/index', getIndex);
router.get('/index/:applicationMode', getIndex);//setup admin page
router.get('/admin', getAdmin);

var applicationModes = util.applicationModes();
var userModes = util.userModes();

var defaultApplicationMode = applicationModes.RUN;

// get package.config or other sources.
var environmentSettings = {
    moduleRegistryPath: global.packageData.moduleRegistryUrl,
    configurationServicePath: global.packageData.configurationServiceUrl,
    moduleRegistryServicePath: global.packageData.moduleRegistryServiceUrl,
    applicationEnvironment: global.packageData.applicationEnvironment,
    environments: global.packageData.environments
}

function getAdmin(req, res, next) {
    res.render('admin', {
        environmentSettings : JSON.stringify(environmentSettings)
    });
};

function getIndex(req, res, next) {
    var applicationMode = getApplicationMode(req);
    if (applicationMode !== null) {
                
        var layoutName = req.query.layoutName;
        var impersonatedUserName = req.query.impersonateUser;
        var userMode = impersonatedUserName ? userModes.IMPERSONATE : (req.query.userMode || userModes.USER);        
        
        var userName = userMode !== userModes.ADMIN ? (userMode === userModes.IMPERSONATE ? impersonatedUserName : req.ntlm.UserName) : null;

        var settings = util.getConfigElement(userMode, userName);        
        
        settings.layouts = settings.layouts || [];
        settings.moduleConfig = settings.moduleConfig || [];
        settings.moduleMappingConfigList = settings.moduleMappingConfigList || [];
        
        var layout = getLayout(settings, layoutName) || { value: {} };
        
        var wsSet = JSON.stringify({
            panelCounter: layout.value.panelCounter || 1,
            moduleList: layout.value.moduleList || [],  // set of modules used in this layout. string array
            workspace: layout.value.workspace ? JSON.parse(layout.value.workspace) : '',   // docker saved format
            moduleConfigList: settings.moduleConfig, // known module listing along with the configuration
            moduleMappingConfigList: settings.moduleMappingConfigList,  // map names of modules to its published name.
            environmentSettings: environmentSettings,
            applicationMode: applicationMode
        });
        
        var userInfo = JSON.stringify({
            userName: req.ntlm.UserName,
            userMode: userMode,
            impersonatedUserName: impersonatedUserName,
            userIP: req.header('x-forwarded-for') || req.connection.remoteAddress
        });

        res.render('index', {
            userInfo: userInfo,
            workspaceSettings: wsSet
        });
    }
    else {
        res.status(404).send('404: Page not Found');
    }
};

function getApplicationMode(req) {
    var mode = req.params["applicationMode"];
    if (mode) {
        
        mode = mode.toLowerCase();
        if (mode === applicationModes.DESIGN || mode === applicationModes.RUN) {
            return mode;
        }
        else
            return null;
    }
    else {
        return applicationModes.RUN;
    }
}

function getLayout(settings, layoutName) {
    
    var result = grep(settings.layouts, function (currentItem) { return currentItem.name == layoutName;  })
    
    if (result.length > 0) {
        return result[0];
    }
}

function getConfigSettings(userMode, userName)
{
    var rootSettings = util.readConfigFile();
    
    if (userMode === userModes.ADMIN) {
        return rootSettings;
    }

    var userSettings = util.readUserConfigFile(userName);

    for (var property in userSettings) {

        var values = userSettings[property];

        for (var index = 0; index < values.length; index += 1) {

            var currentValue = values[index];

            var result = grep(rootSettings[property], function (val) { return val.name == currentValue.name; })
            if (result.length > 0) {
                
                for (var i = 0; i < rootSettings[property].length; ++i) {
                    if (rootSettings[property][i].name === currentValue.name) {
                        rootSettings[property].splice(i, 1);
                        break;
                    }
                }
            }
            rootSettings[property].push(currentValue);            
        }
    }

    return rootSettings;
}

module.exports = router;