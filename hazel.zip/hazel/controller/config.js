﻿"use strict";

var util = require('../utility');
var router = require('express').Router();
var grep = require('grep-from-array');
var userModes = util.userModes();

router.post('/api/config/layout', getAllLayouts);

router.post('/api/config/saveConfig', saveConfig);
router.post('/api/config/saveUserConfig', saveUserConfig);
router.delete('/api/config/deleteConfig', deleteConfig);
router.delete('/api/config/deleteUserConfig', deleteUserConfig);
router.post('/api/config/getConfig', getConfig);
router.post('/api/config/getUserConfig', getUserConfig);


function getAllLayouts(req, res, next){
    
    var userDetail = req.body.userDetail;
    var userName = userDetail.userMode === userModes.IMPERSONATE ? userDetail.impersonatedUserName : req.ntlm.UserName;

    var rootSettings = util.readConfigFile();
    var userSettings = util.readUserConfigFile(userName) ;
    var userMode = userDetail.userMode;
    
    rootSettings.layouts = rootSettings.layouts || [];
    
    if (userMode !== userModes.ADMIN && userSettings) {
        
        var layouts = userSettings.layouts|| {};
        
        for (var index = 0; index < layouts.length; index += 1) {
            
            var currentValue = layouts[index];
            
            var result = grep(rootSettings.layouts, function (val) { return val.name == currentValue.name; })
            if (result.length > 0) {
                
                for (var i = 0; i < rootSettings.layouts.length; ++i) {
                    if (rootSettings.layouts[i].name === currentValue.name) {
                        rootSettings.layouts.splice(i, 1);
                        break;
                    }
                }
            }
            rootSettings.layouts.push(currentValue);
        }
    }

    var arr = [];
    for (var i = 0; i < rootSettings.layouts.length; ++i) {
        arr.push(rootSettings.layouts[i].name);
    }
    
    res.json(arr);    
}

function saveConfig(req, res, next) {
    
    var settings = util.readConfigFile();
    var data = req.body.data;
    
    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;
    
    settings[configElement] = settings[configElement] || [];
    
    //remove prev layout with same name
    deleteElement(settings, configElement, name);
    
    settings[configElement].push({
        name: name,
        value: value
    });
    util.writeConfigFile(settings);
    
    res.json(util.getSuccessResponseMessage());
}

function saveUserConfig(req, res, next) {
    
    var userDetail = req.body.userDetail;
    var data = req.body.data;

    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;

    var userName = userDetail.userMode === userModes.IMPERSONATE ? userDetail.impersonatedUserName : req.ntlm.UserName;
    
    var settings = util.readUserConfigFile(userName);
    if (settings === null) {
        settings = {};
    }
    
    settings[configElement] = settings[configElement] || [];
    
    //remove prev layout with same name
    deleteElement(settings, configElement, name);
    
    settings[configElement].push({
        name: name,
        value: value
    });
    
    util.writeUserConfigFile(userName, settings);
    
    res.json(util.getSuccessResponseMessage());
}

function deleteConfig(req, res, next) {
    
    var settings = util.readConfigFile();

    var data = req.body.data;
    
    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;
    
    settings[configElement] = settings[configElement] || [];
    try {
        
        deleteElement(settings, configElement, name);        
        util.writeConfigFile(settings);
        
        res.json({ message: 'Success' });
    } catch (ex) {
        res.status(500);
        res.json({ message: 'Error in deleting config' });
    }

}

function deleteUserConfig(req, res, next) {
    
    var userDetail = req.body.userDetail;
    var data = req.body.data;
    
    var configElement = data.configElement;
    var name = data.name;
    var value = data.value;

    var userName = userDetail.userMode === userModes.IMPERSONATE ? userDetail.impersonatedUserName : req.ntlm.UserName;
    
    settings[configElement] = settings[configElement] || [];
    try {
        
        deleteElement(settings, configElement, name);
        util.writeUserConfigFile(settings);
        
        res.json({ message: 'Success' });
    } catch (ex) {
        res.status(500);
        res.json({ message: 'Error in deleting config' });
    }

}

function deleteElement(settings, configElement, name) {
    for (var i = 0; i < settings[configElement].length; ++i) {
        if (settings[configElement][i].name === name) {
            return settings[configElement].splice(i, 1);            
        }
    }
}

function getConfig(req, res, next) {
    var settings = util.readConfigFile();
    
    var config = getElement(settings, req);
    
    if (config != null) {
        res.json(config);
    }
    else {
        res.status(400);
        res.json({ message: 'Please supply valid name.' });
    }
}

function getUserConfig(req, res, next) {
    
    var userDetail = req.body.userDetail;
    var userName = userDetail.userMode === userModes.IMPERSONATE ? userDetail.impersonatedUserName : req.ntlm.UserName;

    var settings = util.readUserConfigFile(userName);
    
    var config = getElement(settings, req);
    
    if (config != null) {
        res.json(config);
    }
    else {
        res.status(400);
        res.json({ message: 'Please supply valid name.' });
    }
}

function getElement(settings, req) {
        
    var data = req.body.data;
    
    var configElement = data.configElement;
    var name = data.name;

    var returnConfigElement = null;
    
    settings[configElement] = settings[configElement] || [];
    
    if (typeof name === 'undefined' || name === null || name === '') {
        returnConfigElement = settings[configElement].sort(util.sort_by('name', false));
    }
    else {
        for (var i = 0; i < settings[configElement].length; ++i) {
            if (settings[configElement][i].name === req.body.name) {
                returnConfigElement = settings[configElement][i].value;
                break;
            }
        }
    }
    
    return returnConfigElement;
}

module.exports = router;