﻿'use strict'

var router = require('express').Router();
var util = require('../utility');
var fs = require('fs-extra');

router.get('/decoders', getDecoderList);
router.get('/requestGenerators', getRequestGeneratorList);

function getDecoderList(req, res, next) {
    
    var data = [];
    
    // read all folders of the /data/modules
    var folders = fs.readdirSync('controller/js/streaming/decoder');
    
    // read name from package.json
    for (var i = 0; i < folders.length; ++i) {
        try {
            data.push(folders[i].substring(0, (folders[i].length - 3)));
        } catch (ex) {
            // package.json was not found
        }
    }
    
    data.sort(util.sort_by('name', false));
    
    res.json(data);
}

function getRequestGeneratorList(req, res, next) {
    
    var data = [];
    
    // read all folders of the /data/modules
    var folders = fs.readdirSync('controller/js/streaming/requestGenerator');
    
    // read name from package.json
    for (var i = 0; i < folders.length; ++i) {
        try {
            data.push(folders[i].substring(0, (folders[i].length - 3)));
        } catch (ex) {
            // package.json was not found
        }
    }
    
    data.sort(util.sort_by('name', false));
    
    res.json(data);
}

module.exports = router;