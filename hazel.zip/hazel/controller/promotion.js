﻿'use strict';

var router = require('express').Router();
var util = require('../utility');
var nodeSettings = require('./../applicationSettings.json');
var grep = require('grep-from-array');

router.post('/', promotelement);

var elementTypes = [{ name: 'moduleMappingConfigList', type: 'moduleregistry' }, 
            { name: 'sharedConfig', type: 'moduleregistry' }, 
            { name: 'layouts', type: 'config' }, 
            { name: 'dataSourceList', type: 'config' }
        ];

function promotelement(request, response, next) {

    var requestedElements = request.body.elements;
    var destinationEnvironment = request.body.destinationEnvironment;
    
    var configElements = [];
    var moduleRegistryElements = [];

    for (var current in requestedElements) {
        
        if (getElementType(current) === 'config') {
            var element = requestedElements[current];
            var names = [];
            
            for (var nameIndex = 0; nameIndex < element.length; nameIndex += 1) {
                names.push(element[nameIndex].name);
            }
            
            configElements.push({ configElement: current, name: names });
        }
        else if (getElementType(current) === 'moduleregistry') {
            
            var element = requestedElements[current];
            var names = [];
            
            for (var nameIndex = 0; nameIndex < element.length; nameIndex += 1) {
                names.push(element[nameIndex].name);
            }
            
            moduleRegistryElements.push({ configElement: current, name: names });
            if (current === 'moduleMappingConfigList') {
                moduleRegistryElements.push({ configElement: 'moduleConfig', name: names });
            }
        }
    }
    
    if (configElements.length > 0) {
        uploadConfig(destinationEnvironment, configElements, requestedElements);
    }

    if (moduleRegistryElements.length > 0) {

        uploadModuleConfig(destinationEnvironment, moduleRegistryElements, requestedElements);
    }

    response.json(requestedElements);
}

function getElementType(name)
{
    var result = grep(elementTypes, function (currentItem) { return currentItem.name == name; })
    if (result.length > 0) {
        return result[0].type;
    }
}

function uploadConfig(destinationEnvironment, configElements, requestedElements)
{
    try {
        var configValues = util.getConfig(configElements);
        
        var apiUrl = nodeSettings.settings[destinationEnvironment].configurationServiceUrl;
        
        var response = util.saveConfig(configValues, apiUrl);
        
        if (response.status === 'error') {
            console.log('Status: ' + response.status + ', Message: ' + response.message);
        }
        configElements.forEach(function (item) {

            updateStatus(requestedElements, item.configElement, null, this.status === 'error' ? false :true);
        }, response);
    }
    catch (xe) {
        console.log('UploadConfig-->Error:' + xe.message);
        
        configElements.forEach(function (item) {
            updateStatus(requestedElements, item.configElement, null, false);
        });
        
    }
}

function uploadModuleConfig(destinationEnvironment, moduleRegistryElements, requestedElements)
{
    var configValues = util.getConfig(moduleRegistryElements);
    
    var apiUrl = nodeSettings.settings[destinationEnvironment].moduleRegistryServiceUrl;
    
    for (var configValueIndex = 0; configValueIndex < configValues.length; configValueIndex++) {
        
        var currentElement = configValues[configValueIndex];
        
        if (currentElement.name === 'moduleMappingConfigList') {                        
            
            var uploadedModules = [];
            
            for (var index = 0; index < currentElement.value.length; index++) {
                                
                var currentItem = currentElement.value[index];
                
                try {
                    var modulePackage = null;
                    
                    var result = grep(uploadedModules, function (item) { return item.moduleName == currentItem.value.ModuleName; })
                    if (result.length <= 0) {
                        modulePackage = util.getModulePackage(currentItem);
                        
                        uploadedModules.push({ moduleName : currentItem.value.ModuleName });
                    }
                    
                    var moduleElement = {
                        config: createConfigElement(getModuleConfig(configValues, currentItem.name), currentItem),
                        modulePackage: modulePackage,
                        moduleName: currentItem.value.ModuleName
                    };
                    
                    var response = util.uploadModulePackage(moduleElement, apiUrl);                    
                    updateStatus(requestedElements, currentElement.name, currentItem.name, response.status === 'error' ? false :true);
                }
                catch (xe) {
                    console.log('UploadModuleConfig-->Error: ' + xe.message);
                    updateStatus(requestedElements, currentElement.name, currentItem.name, false);
                }
            }
        }
        else if (currentElement.name === 'sharedConfig') {
            
            for (var index = 0; index < currentElement.value.length; index++) {
                
                var currentItem = currentElement.value[index];
                try {
                    var fileName = currentItem.value.filename;
                    
                    var sharedModuleElement = {
                        config: [{
                                name: 'sharedConfig',
                                value: [currentItem],                                
                            }],
                        modulePackage: util.getSharedResourcePackage(currentItem),
                    }
                    
                    var response = util.promoteSharedResourcePackage(sharedModuleElement, apiUrl);
                    updateStatus(requestedElements, currentElement.name, currentItem.name, response.status === 'error' ? false :true);
                }
                catch (xe) {
                    console.log('UploadModuleConfig-->Error: ' + xe.message);
                    updateStatus(requestedElements, currentElement.name, currentItem.name, false);
                }
            }
        }
        
    }
}

function createConfigElement(moduleConfig, moduleMappingConfig)
{
    var config = [{
            name: 'moduleConfig',
            value: [moduleConfig[0]],                                
        },
        {
            name: 'moduleMappingConfigList',
            value: [moduleMappingConfig]
        }];

    return config;
}

function getModuleConfig(configs, itemName)
{
    var element = grep(configs, function (item) { return item.name == 'moduleConfig'; })

    if (element.length > 0) {
        return grep(element[0].value, function (item) { return item.name == itemName; })
    }
}

function updateStatus(elements, configElementName, itemName, status)
{
    var currentElement = elements[configElementName];
    if (currentElement !== null) {
        if (itemName !== null) {
            var result = grep(currentElement, function (item) { return item.name == itemName; })
            if (result.length > 0) {
                result[0].status = status;
            }
        }
        else {
            currentElement.forEach(function (item) {
                item.status = status;
            });
        }
    }
}



module.exports = router;