﻿'use strict';

var router = require('express').Router();
var dataSource = require('./js/streaming/dataSource.js');
var util = require('../utility');

router.use(crossOriginHandler);
router.post('/', getData);

// enable CORS for all requests
function crossOriginHandler(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
};

function getData(request, response, next) {
    
    //var dataSourceName = request.body.dataSourceName;
    var queryParameters = request.body.queryParameters;
    //get datasource information
    var dataSourceConfig = request.body.dataSourceConfig; //util.getConfig('dataSourceList', dataSourceName);// getDataSource(dataSourceName);
    var requestInfo = {
        userInfo: {
            UserName: request.ntlm.UserName,
            DomainName: request.ntlm.DomainName,
            MachineName: request.ntlm.Workstation
        },
        applicationName: 'Opportunity'
    }
    
    if (dataSourceConfig !== null) {
        updateQueryParameter(queryParameters, dataSourceConfig)
        
        var reponseObject = dataSource.getData(dataSourceConfig, requestInfo, function (data, message) {
            
            if (data !== null) {
                response.json(data);
            }
            else {
                response.status(502);
                response.json({ Error: message });
            }
        });
    }
    else {
        response.end('Invalid DataSource');
    }
}

function getDataSource(dataSourceName) {
    var settings = util.readConfigFile();
    
    for (var i = 0; i < settings.dataSourceList.length; ++i) {
        if (settings.dataSourceList[i].name === dataSourceName) {
            return settings.dataSourceList[i];
        }
    }

    return null;
}

function updateQueryParameter(queryParameters, dataSourceConfig) {
        
    for (var current in queryParameters) {
        if (queryParameters.hasOwnProperty(current)) {
            if (typeof dataSourceConfig.queryParameters[current] === 'undefined') {
                dataSourceConfig.queryParameters[current] = {};
            }
            dataSourceConfig.queryParameters[current].value = queryParameters[current];
        }
    }
}

module.exports = router;