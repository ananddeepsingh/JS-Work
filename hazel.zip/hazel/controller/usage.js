﻿"use strict";

var router = require('express').Router();
router.post('/', logModuleUsage);

var mongodb = require('mongodb');
var client = mongodb.MongoClient;

var connectionString = global.packageData.mongodbConnectionString;
var moduleUsageCollectionName = 'ModuleUsage';  

var dbInstance;

function logModuleUsage(req, res, next){
    
    if (!req.body) {
        res.end();
        return;
    }
    
    if (!dbInstance) {
        client.connect(connectionString, function (err, db) {
            if (err) {
                console.error('cannot connect to mongodb ' + err);
            } else {
                dbInstance = db;
            }
        });
    }
    else {
        var collection = dbInstance.collection(moduleUsageCollectionName);
        
        collection.insert(req.body, function (err, result) {
            if (err) {
                console.log('cannot insert data ' + err);
            } else {
                console.log('Inserted');
            }
        });
        res.end();
    }
}

//clean the connection on exit of application
process.on('SIGHUP', function () {
    if(dbInstance)
        dbInstance.close();
});

//clean the connection on exit of application
process.on('SIGINT', function () {
    if (dbInstance)
        dbInstance.close();

    process.exit(0);
});


module.exports = router;