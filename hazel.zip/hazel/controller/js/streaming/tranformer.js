﻿'use strict';

function getColumnNames(dataObject) {
    var schemaData = dataObject.data.rows[0].cells[1].listValue;
    
    var columnNames = [];
    
    for (var index = 0; index < schemaData.length; index += 1) {
        
        columnNames.push(schemaData[index].cells[0].primitiveString);
    }
    
    return columnNames;
}

function getTableData(dataObject, columnNames) {
    
    var queryReponseTable = dataObject.data;
    
    var tableData = queryReponseTable.rows[0].cells[2].listValue;
    
    var data = [];
    for (var index = 0; index < tableData.length; index += 1) {
        var row = {};
        
        for (var columnIndex = 0; columnIndex < columnNames.length; columnIndex += 1) {
            
            row[columnNames[columnIndex]] = tableData[index].cells[0].listValue[columnIndex].cells[0].primitiveString;
        }
        
        data.push(row);
    }
    
    return data;
}

exports.tranform = function (dataObject) {
    
    var columnNames = getColumnNames(dataObject);
    
    var returnData = getTableData(dataObject, columnNames);
    
    return returnData;
};
