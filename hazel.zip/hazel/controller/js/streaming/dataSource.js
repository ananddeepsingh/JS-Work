﻿"use strict";

var http = require('http');
var urlparser = require('url-parse');
var zlib = require('zlib');

var compressTypes = {
    GZIP: 'gzip',
    NONE: 'none'
};

exports.getData = function (dataSourceConfig, requestInfo, callback) {
    
    if (dataSourceConfig.type === 'http') {
        var hostUrl = dataSourceConfig.hostUrl;
        var urlObject = urlparser(hostUrl);
        
        var hostName = urlObject.hostname;
        var port = urlObject.port !== '' ? urlObject.port: '80';
        var path = urlObject.pathname !== '' ? urlObject.pathname:'/';
        var query = urlObject.query;
        
        var decoderName = dataSourceConfig.decoder;
        var requestGeneratorName = dataSourceConfig.requestGenerator;
        var decodeChunks = dataSourceConfig.decodeChunks;
        
        var decoder = require('./decoder/' + decoderName + '.js');
        var requestGenerator = require('./requestGenerator/' + requestGeneratorName + '.js');
        
        var requestMessage = requestGenerator.generate(dataSourceConfig, requestInfo);
        
        var headers = {
            encoding: null
        };
        
        var options = {
            host: hostName,
            port: port,
            path: path + query,
            method: 'POST',
            headers: headers
        };
        
        var httpRequest = http.request(options, function (httpReponse) {
            
            var responseBuffer = [];
            
            httpReponse.on('data', function (data) {
                responseBuffer.push(data);
            });
            
            httpReponse.on('end', function () {
                
                try {
                    responseBuffer = Buffer.concat(responseBuffer);
                    
                    var compressType = getCompressType(responseBuffer);
                    
                    if (compressType === compressTypes.GZIP) {
                        zlib.gunzip(responseBuffer, function (error, decodedBuffer) {
                            
                            var dataObject = decoder.decode(decodedBuffer, decodeChunks);
                            callback(dataObject);
                        });
                    }
                    else {
                        
                        var dataObject = decoder.decode(responseBuffer, decodeChunks);
                        callback(dataObject);
                    }
                }
            catch (decodeException) {                    
                    console.log('Decoder:'+decoderName+', Error in decoding response:' + decodeException);
                    callback(null, 'Internal Server Error.');
                }
            });
           
        });
        
        httpRequest.on('error', function (requestError) {
            console.log('Error in making request to service. Error: ' + requestError);
            callback(null, 'Error in making request to service.');
        });
        
        httpRequest.write(requestMessage);
        httpRequest.end();
    }
    else if (dataSourceConfig.type === 'csv') {
        var decoder = require('./decoder/csvResponseDecoder.js');
        var dataObject = decoder.decode(dataSourceConfig.file);
        callback(dataObject);
    }
};

function getCompressType(buffer){
    if (buffer.length > 0 && buffer[0] === 0x1f && buffer[1] === 0x8b) {
        return compressTypes.GZIP;
    }
    else {
        return compressTypes.NONE;
    }
}