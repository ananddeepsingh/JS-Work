﻿
'use strict';

var protobuf = require('protobufjs');
var util = require('../../../../utility');
var xml2js = require('xml2js');

exports.decode = function (responseMessage, decodeChunks) {
    
    var protoDataObject = deserializeResponse(responseMessage);
    
    var jsonDataObject = transformData(protoDataObject);
    
    return jsonDataObject;
};

function deserializeResponse(responseMessage) {
    
    console.log('Deserializing the response');
    
    var deserializedObject;
    
    var xmlResponse = String(responseMessage, 'base128');
    
    var parseString = xml2js.parseString;
    
    parseString(xmlResponse, function (err, result) {
        deserializedObject = result;
    });
    
    return deserializedObject;
}

function transformData(dataObject) {        
    
    var transformedData = getTableData(dataObject);
    
    return transformedData;
}

function getTableData(dataObject, columnList) {
    
    var data = [];

    var tableData = dataObject.Response.CDSTrade;
    
    if (tableData) {
        console.log('Record(s) recevied: [' + tableData.length + ']');
                
        for (var index = 0; index < tableData.length; index += 1) {
            var row = {};
            var currentRow = tableData[index];
            
            for (var field in currentRow) {
                row[field] = currentRow[field][0];
            }
            
            data.push(row);
        }
    }
    else {
        console.log(dataObject.Response.status[0]._);
    }
    
    return data;
}