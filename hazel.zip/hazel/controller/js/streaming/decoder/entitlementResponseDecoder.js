﻿
'use strict';

var protobuf = require('protobufjs');
var util = require('../../../../utility');

var startPosition = 0;
var bytesRead = 0;
var tmpBytesRead = 0;

exports.decode = function (responseMessage, decodeChunks) {
    
    var protoDataObject = deserializeResponse(responseMessage);

    var jsonDataObject = transformData(protoDataObject);

    return jsonDataObject;
};

function deserializeResponse(responseMessage) {

    console.log('Deserializing the response');
    
    var deserializedObject;
    var length = 0;
    startPosition = 0;
    
    if (!protobuf) {
        throw (new Error("ProtoBuf.js is not present. Please contact administrator."));
    }
    
    var tableObject = protobuf.loadProtoFile("controller/js/streaming/proto/Table.proto").build("Table");
    
    do {
        
        length = readLengthPrefix(responseMessage, startPosition);
        if (length > 0) {
            
            var startIndex = startPosition + bytesRead;
            var endIndex = length + bytesRead + startPosition;
            
            var responseTable = tableObject.decode(responseMessage.slice(startIndex, endIndex));
            
            if (deserializedObject != null) {                
                deserializedObject = addRowsToMaster(responseTable, deserializedObject);
            }
            else {
                deserializedObject = responseTable;
            }
            startPosition = endIndex;
        }
    } while(length > 0)
    
    return deserializedObject;
}

function readLengthPrefix(message, currentIndex) {
    
    bytesRead = 0;
    tmpBytesRead = 0;
    
    var value = readVarint(message, currentIndex);
    bytesRead += tmpBytesRead;
    
    if (tmpBytesRead > 0) {
        
        var value = readVarint(message, currentIndex === 0? bytesRead: currentIndex + bytesRead);
        bytesRead += tmpBytesRead;
        if (bytesRead == 0) {

            return 0;
        }
        
        return value;
    }
}

function readVarint(bytes, currentIndex) {
    var ret = 0;
    for (var i = 0; ; i++) {
        
        tmpBytesRead = i + 1;
        
        var byte = bytes[i + currentIndex];
        ret |= (byte & 0x7F) << (7 * i);
        if ((byte >> 7) == 0) break;
    }
    return ret;
}

function addRowsToMaster(sourceObject, destObject) {
    
    for (var index = 0; index < sourceObject.Rows.length; index += 1) {
        
        destObject.Rows.push(sourceObject.Rows[index]);
    };

    return destObject;
}

function transformData(dataObject) {

    console.log('Reading columns metadata.');
    
    var elements = [];
    elements.push({ configElement: 'schemaList', name : ['entitlement'] });

    var element = util.getConfig(elements);
    var columnList;
    if (element.length > 0) {
        columnList = element[0].value[0].value;
    }

    var jsonData = processRows(dataObject.Rows, columnList);

    return jsonData;
}

function processRows(rows, columnList) {
    
    var data = [];
    for (var index = 0; index < rows.length; index += 1) {
        
        var row = processCells(rows[index].Cells, columnList);
        
        data.push(row);
    }

    return data;
}

function processCells(cells, columnList) {
    
    var row = {};
    
    for (var columnIndex = 0; columnIndex < columnList.length; columnIndex += 1) {
        
        var currentColumn = columnList[columnIndex];
        var columnName = currentColumn.name;
        
        if (currentColumn.type === 'complex') {            
            if (cells[columnIndex].ComplexValue !== null) {
                
                row[columnName] = processCells(cells[columnIndex].ComplexValue.Cells, currentColumn.list);
            }
            else {
                row[columnName] = null;
            }
        }
        else if (currentColumn.type === 'list') {
            if (cells[columnIndex].ListValue !== null) {
                
                row[columnName] = processRows(cells[columnIndex].ListValue.Rows, currentColumn.list);
            }
            else {
                row[columnName] = null;
            }
        }
        else {
            row[columnName] = cells[columnIndex].PrimitiveValue;
        }
    }
    
    return row;
}
