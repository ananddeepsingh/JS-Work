﻿
'use strict';

exports.decode = function (responseMessage, decodeChunks) {
    
    var protoDataObject = deserializeResponse(responseMessage);
    
    var jsonDataObject = transformData(protoDataObject);
    
    return jsonDataObject;
};

function deserializeResponse(responseMessage) {
    
    console.log('Deserializing the response');
    
    var xmlResponse = String(responseMessage, 'base128');
    
    return JSON.parse(xmlResponse);
}

function transformData(dataObject) {
    
    if (dataObject.responseStatus === 'OK') {
        
        var columnList = dataObject.content.header;
        
        var transformedData = getTableData(dataObject, columnList);
        
        return transformedData;
    }

    return null;
}

function getTableData(dataObject, columnList) {
    
    var data = [];    
    var rows = dataObject.content.rows;

    console.log('Record(s) recevied: [' + rows.length + ']');
    
    for (var rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
        var row = {};
        var currentRow = rows[rowIndex];
        
        for (var cellIndex = 0; cellIndex < currentRow.data.length; cellIndex += 1) {
            row[columnList[cellIndex]] = currentRow.data[cellIndex];
        }
        
        data.push(row);
    }
    
    return data;
}