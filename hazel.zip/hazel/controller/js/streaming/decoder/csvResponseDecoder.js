﻿'use strict';

var csvjson = require('csvjson');

var path = require('path');

exports.decode = function (fileName) {
    
    var returndata = [];
    
    try {
        returndata = csvjson.toObject(path.resolve(fileName)).output;
    }
    catch (xe) {
        console.log('CSVDecoder-->Error in reading csv data. Error: ' + xe.message);
    }
    
    return returndata;
};