﻿
'use strict';

var protobuf = require('protobufjs');

exports.decode = function (responseMessage, decodeChunks) {
    
    var protoDataObject = deserializeResponse(responseMessage, decodeChunks);
    
    var jsonDataObject = transformData(protoDataObject);
    
    return jsonDataObject;
};

function deserializeResponse(responseMessage, decodeChunks) {
    
    console.log('Deserializing the response');
    
    if (!protobuf) {
        throw (new Error("ProtoBuf.js is not present. Please contact administrator."));
    }
    
    var genericTableObject = protobuf.loadProtoFile("controller/js/streaming/proto/GenericTable.proto").build("GenericTable");
    
    if (decodeChunks === true) {
        var deserializedObject = genericTableObject.decodeDelimited(responseMessage);
    }
    else {
        var deserializedObject = genericTableObject.decode(responseMessage);
    }
    
    return deserializedObject;
}

function transformData(dataObject) {
    
    var columnList = getColumnList(dataObject);
    
    var transformedData = getTableData(dataObject, columnList);
    
    return transformedData;
}

function getColumnList(dataObject) {
    
    console.log('Reading columns metadata.');

    var schemaData = dataObject.data.rows[0].cells[1].listValue;
    
    var columnList = [];
    
    for (var index = 0; index < schemaData.length; index += 1) {
        
        columnList.push(schemaData[index].cells[0].primitiveString);
    }
    
    return columnList;
}

function getTableData(dataObject, columnList) {
    
    var queryReponseTable = dataObject.data;
    
    var tableData = queryReponseTable.rows[0].cells[2].listValue;
    
    console.log('Record(s) recevied: ['+tableData.length+']');
    
    var data = [];
    for (var index = 0; index < tableData.length; index += 1) {
        var row = {};
        
        for (var columnIndex = 0; columnIndex < columnList.length; columnIndex += 1) {
            
            if (typeof tableData[index].cells[0] !== 'undefined' && tableData[index].cells[0].listValue[columnIndex].cells[0].primitiveString != null) {

                row[columnList[columnIndex]] = tableData[index].cells[0].listValue[columnIndex].cells[0].primitiveString;
            }
            else {
                console.log('Not a string type.');
            }
        }
        
        data.push(row);
    }
    
    return data;
}