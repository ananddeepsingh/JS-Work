﻿'use strict';

var builder = require('xmlbuilder');

exports.generate = function (dataSourceConfig, requestInfo) {
        
    var requestMessage = createRequest(dataSourceConfig, requestInfo);
    return requestMessage;
};

function createRequest(dataSourceConfig, requestInfo)
{
    var request = builder.create("Request");

    var headerElement = request.ele('Header');
    createHeaderProperties(headerElement, requestInfo);

    var operationElement = request.ele('Operation');
    createOperation(operationElement, dataSourceConfig.operation)

    var paramsElement = request.ele('Params');
    createParameters(paramsElement, dataSourceConfig.queryParameters);

    return request.toString();
}

function createHeaderProperties(headerElement, requestInfo)
{
    createHeaderProperty(headerElement, "userid", requestInfo.userInfo.UserName);
    createHeaderProperty(headerElement, "kerberosTicket", "false");
    createHeaderProperty(headerElement, "ip", requestInfo.userInfo.MachineName);
    createHeaderProperty(headerElement, "pid", "1234");
    createHeaderProperty(headerElement, "useprotobuf", "false");
    createHeaderProperty(headerElement, "DomainName", requestInfo.userInfo.DomainName);
    createHeaderProperty(headerElement, "ApplicationName", requestInfo.applicationName);
}

function createHeaderProperty(headerElement, name, value)
{
    var propertyElement = headerElement.ele("Property");
    propertyElement.ele("Name").txt(name);
    propertyElement.ele("Value").txt(value);
}

function createOperation(operationElement, operationName)
{
    operationElement.txt(operationName);
}

function createParameters(paramsElement, parameters) {

    for (var current in parameters) {        
        paramsElement.ele(current).txt(parameters[current].value === null ? '' : parameters[current].value);
    }
}