﻿'use strict';

var builder = require('xmlbuilder');

exports.generate = function (dataSourceConfig, requestInfo) {
        
    var requestMessage = createRequest(dataSourceConfig, requestInfo);
    return JSON.stringify(requestMessage);
};

function createRequest(dataSourceConfig, requestInfo)
{
    var request = {};    

    request['header'] = {};
    createHeaderProperties(request.header, requestInfo);

    request['operation'] = dataSourceConfig.operation;
    createParameters(request, dataSourceConfig.operationParameters);

    request['params'] = {};
    createParameters(request.params, dataSourceConfig.queryParameters);

    return request;
}

function createHeaderProperties(header, requestInfo)
{    
    header.applicationName = requestInfo.applicationName;
    header.systemuser = requestInfo.userInfo.UserName;
    header.region = requestInfo.userInfo.region;
}

function createParameters(element, parameters) {
    
    for (var current in parameters) {        
        element[current] = parameters[current].value;
    }
}