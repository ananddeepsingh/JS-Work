﻿
'use strict';
var fs = require('fs');

var protobuf = require('protobufjs');

var protobufBuffer = require('protocol-buffers')

var ByteBuffer = protobuf.ByteBuffer;

var data = ByteBuffer.fromHex(fs.readFileSync('controller/js/streaming/proto/data.txt', 'utf8'));

exports.decode = function (responseMessage) {
    
    //if (!protobuf) {
    //    throw (new Error("ProtoBuf.js is not present. Please see www/index.html for manual setup instructions."));
    //}
    
    //var genericTable = protobufBuffer(fs.readFileSync("controller/js/streaming/proto/GenericTable.proto"));
    
    //var queryResponseGenericTable = null;
    //try {
    //    queryResponseGenericTable = genericTable.GenericTable.decode(data.buffer);
    //}
    //catch (xe) {
    //    console.log(xe);
    //}
    
    var genericTable = protobuf.loadProtoFile("controller/js/streaming/proto/GenericTable.proto").build("GenericTable");
    
    var queryResponseGenericTable = genericTable.decode(data.buffer);
    
    return queryResponseGenericTable;
};
