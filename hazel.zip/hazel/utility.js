﻿"use strict";

var syncRequest = require('sync-request');

var responseMessage = {
    success: {
        message:'Ok'
    },
    error: {
        message: 'Error'
    }
};

exports.getSuccessResponseMessage = function () {
   
    return responseMessage.success;
}

exports.getErrorResponseMessage = function () {
    
    return responseMessage.error;
}

exports.getSchema = function (schemaName) {

    var schema = null;
        
    var res = syncRequest('POST', global.packageData.configurationServiceUrl + 'getConfig', {
        json: { data: { configElement: 'schemaList', name: schemaName } }
    });
    schema = JSON.parse(res.getBody('utf8'));
    
    return schema;
}

exports.userModes = function() {
    return {
        ADMIN: 'admin',
        USER: 'user',
        IMPERSONATE: 'impersonate'
    }
};

exports.applicationModes = function () {
    return {
        RUN: 'run',
        DESIGN: 'design'
    }
};

exports.sort_by = function (field, reverse) {
    
    var key = function (x) { return x[field] };
    
    reverse = !reverse ? 1 : -1;
    
    return function (a, b) {
        
        return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
    }
}

exports.getConfigElement = function (userMode, userName) {

    var res = syncRequest('POST', global.packageData.configurationServiceUrl + 'getSettings', {
        json: { userDetail: { userName: userName } }
    });
    return JSON.parse(res.getBody('utf8'));
}

exports.getConfig = function(elements)
{
    var res = syncRequest('POST', global.packageData.configurationServiceUrl + 'getConfig', {
        json: { data: elements }
    });
    return JSON.parse(res.getBody('utf8'));
}

exports.saveConfig = function (configElement, configurationServiceUrl) {
    
    var url = configurationServiceUrl || global.packageData.configurationServiceUrl;
    var res = syncRequest('POST', url + 'saveConfig', {
        json: { data: configElement }
    });
    return getResponse(res);
}

exports.getModulePackage = function (elements) {

    var res = syncRequest('POST', global.packageData.moduleRegistryServiceUrl + 'getModulePackage', {
        json: { data: elements }
    });

    return getResponse(res);
}

exports.uploadModulePackage = function (elements, moduleRegistryServiceUrl) {
    
    var url = moduleRegistryServiceUrl || global.packageData.moduleRegistryServiceUrl;

    var res = syncRequest('POST', url + 'promoteModulePackage',{
        json: { data: elements }
    });
    
    return getResponse(res);
}

exports.getSharedResourcePackage = function (elements) {
    
    var res = syncRequest('POST', global.packageData.moduleRegistryServiceUrl + 'getSharedResourcePackage', {
        json: { data: elements }
    });
    
    return getResponse(res);
}

exports.promoteSharedResourcePackage = function (elements, moduleRegistryServiceUrl) {
    
    var url = moduleRegistryServiceUrl || global.packageData.moduleRegistryServiceUrl;

    var res = syncRequest('POST', url + 'promoteSharedResourcePackage', {
        json: { data: elements }
    });

    return getResponse(res);
}

function getResponse(res)
{
    if (res.statusCode === 404) {
        return { status: 'error', message: 'Not Found, client was able to communicate with a given server' };
    }
    else if (res.statusCode === 500) {
        return { status: 'error', message: 'Internal Server Error' };
    }
    else {
        return res.getBody();
    }
}