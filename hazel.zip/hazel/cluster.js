﻿"use strict"

// Include the cluster module
var cluster = require('cluster');

var nodeSettings = require('./nodeSettings.json');
var applicationEnvironment = nodeSettings.applicationEnvironment; // get env of the appEnv

var forkCount = nodeSettings.settings[applicationEnvironment].forkcount;

if (cluster.isMaster) {
    
    // Count the machine's CPUs
    var cpuCount  = require('os').cpus().length;
    
    // Create a worker for each CPU
    for (var i = 0; i < forkCount ; i++) {
        cluster.fork();
    }
    
    // Listen for dying workers
    cluster.on('exit', function (worker, code, signal) {
                
        console.log('worker ' + worker.process.pid + ' died');
        // Replace the dead worker
        cluster.fork();

    });

} else {
        
    require("./app.js");
}