﻿"use strict";

define(['sandbox', 'lib/eventemitter3', 'jquery', 'nameService'],
    function (Sandbox, EventEmitter, $, nameService) {
    
    var _modulePath = 'modules/';
    
    var loadedModules = [];
    var _core;
        
    var sandboxes = [];
    var interactionService;
    
    function init(core, listModules) {

        _core = core;
        interactionService = _core.getService('interactionService');
        
        preLoadModules(listModules).then(function (data) {
            
            initModules(listModules);
            renderModules();

        });
    }
    
    function initModules(listModules) {
        
        for (var index = 0; index < listModules.length; index += 1) {
            
            var module = listModules[index];
            
            var settings = getModuleConfiguration(module.publishedName);
            var moduleSettings = getModuleSettings(settings);
            
            try {
                var sb = getSandbox(module);
                sb.init(module, settings);
            } catch (ex) {
                _core.getService('interactionService').showError('Error ' + module.publishedName, ex.message);
            }
        }
    }
    
    // NOTE: copied from Sandbox.js remove through prototype of moduleManager
    function getModuleSettings(configSettings) {
        //TODO: temp. hack to cast
        return configSettings ? (configSettings.value ? (typeof configSettings.value.module !== 'object' ? (typeof configSettings.value.module !== 'undefined' ? $.parseJSON(configSettings.value.module): configSettings.value.module): configSettings.value.module): undefined): undefined;
    }
    
    function renderModules() {
        
        for (var index = 0; index < sandboxes.length; index += 1) {
            
            var sandbox = sandboxes[index];
            if (sandbox.canRender()) {
                
                var panel = _core.layoutService.getPanel(sandbox.module) || _core.layoutService.createPanel(sandbox.module);
                sandbox.render(panel);
            }

        }
    }
    
    function getSandbox(module) {
        
        var sandBox = new Sandbox(_core, module);
        sandboxes.push(sandBox);
                
        // extend eventEmitter
        var ee = new EventEmitter();
        $.extend(sandBox, ee, sandBox);
        
        // listen to close event
        sandBox.on('close', function () {
            sandboxes.splice(sandboxes.indexOf(sandBox), 1);
        });
        
        return sandBox;
    }
    
    function createModule(module, moduleSettings) {
        
        var panel = null;
        var sandbox = getSandbox(module);
        
        module.id = nameService.getUniqueName(module.name, _core);
        sandbox.init(module, moduleSettings);
        
        if (sandbox.canRender()) {
            panel = _core.layoutService.createPanel(sandbox.module);
            sandbox.render(panel);
        }
    }
    
    function preLoadModules(listModules) {
        var moduleNames = [];
        
        for (var i = 0; i < listModules.length; i += 1) {
            moduleNames.push(listModules[i].name);
        }
        
        return new $.Deferred(function (defer) {
            var cb = function (name) {
                
                require([_core.helper.getModulePath(name, _core)], function (module) {
                    if (moduleNames.length) {
                        cb(moduleNames.pop());
                    }
                    else {
                        defer.resolve();
                    }
                }, function (error) {
                    
                    _core.getService('logger').write({
                        type: 'ERROR',
                        message: 'Error in loading module:[' + name + ']',
                        moduleName: 'Module Manager:PreLoadModules()'
                    });
                    
                    if (moduleNames.length) {
                        cb(moduleNames.pop());
                    }
                    else {
                        defer.resolve();
                    }
                });
            };
            
            var mName = moduleNames.pop();
            if (mName) {
                cb(mName);
            }
        }).promise();
    }
    
    function getModuleConfiguration(moduleName) {
        
        var moduleConfigList = _core.workspaceSettings.moduleConfigList;
        
        var result = $.grep(moduleConfigList, function (e) { return e.name == moduleName; });
        if (typeof result !== 'undefined' && result.length > 0) {
            return result[0];
        }
        
        return null;
    }
    
    function renderDialogConfig(element, store, module) {
        
        element.html('');
        
        showWaitLoader(element);
        
        require([_core.helper.getModulePath(module.name, _core)], function (loadedModule) {
            
            // create a throwaway snadbox only. actual to be created by getSandbox.
            store.sandbox = new Sandbox(_core, module);
            
            var configSettings = getModuleConfiguration(module.publishedName);
            
            if (store.sandbox.renderEditor) {
                store.sandbox.renderEditor(element, configSettings);
            }
            
            hideWaitLoader();

        }, function (error) {
            
            _core.getService('logger').write({
                type: 'ERROR',
                message: 'Error in loading module:[' + module.id + '], name:[' + module.name + ']',
                moduleName: 'Module Manager'
            });
            
            hideWaitLoader();
            console.error(error);
            
            _core.helper.renderModuleLoadErrorMessage(element);            
        });
    }
    
    function addModulePanel(panelType) {
        
        var div = $('<div title="Add module"/>');

        var select = getSelectionControl(div, function (e, obj) {
            var value = obj.item.value;
            if (value !== 'default') {
                renderDialogConfig(propdiv, tempObj, { name: _core.helper.getModuleName(value), publishedName: value });
            }
            else {
                propdiv.html('');
            }
        });
        
        var propdiv = $('<div/>');
        div.append(select);
        div.append($('<div/>').addClass('ui-button ui-widget ui-button-icon-primary ui-icon ui-icon-circle-triangle-s').click(function () { select.autocomplete('search', ''); select.focus(); }));

        div.append(propdiv);        

        var tempObj = {};
        tempObj.sandbox = {};               
        
        interactionService.showDialog(div, {
            Ok: function () {
                var selectedModule = select.val();
                if (selectedModule !== 'default') {
                    if (select.val()) {
                        var settings = tempObj.sandbox.getSettings();
                        tempObj.sandbox.saveSettings();
                        createModule({ name: _core.helper.getModuleName(selectedModule), publishedName: selectedModule, isHidden: false, dockstate: 'float', option: { h: '140px', w: '500px', x: '330', y: '333' } }, settings);
                        
                        $(this).dialog('destroy');
                        select.remove();
                    }
                }
            },
            Cancel: function () {
                $(this).dialog('destroy');
                select.remove();
            }
        });
    }
    
    function isModuleExists(moduleName)
    {
        var result = $.grep(sandboxes, function (e) { return e.module.publishedName == moduleName; });
        if (result.length > 0) {
            alert('Module already added in layout');
            return false;
        }
        
        return true;        
    }
    
    function getSelectionControl(root, changeCallback){
        return $('<input/>').autocomplete({
            source: function (request, response){
                response(getAddModuleOptions(request.term));                
            },
            select: changeCallback,
            minLength: 0,

            open: function (event, ui){
                var widget = $(this).data('ui-autocomplete'),
                    menu = widget.menu,
                    ul = menu.element;
                $(ul).zIndex(+root.zIndex() + 1);
            }
        })
    }

    function getAddModuleOptions(searchTerm) {
        var list = _core.workspaceSettings.moduleConfigList;
        
        if (searchTerm !== '') {
            list = $.grep(list, function (n, i) {
                
                var r = new RegExp(searchTerm, 'gi');
                // find matching published name or one of the keywords
                return n.name.match(r)  
                    || (n.keywords && n.keywords.match(r));
            });
        }
        
        return $.map(list, function (n, i) {
            // returns type that is understood by autocomplete
            return {
                label: n.name,
                value: n.name
            }
        })
    }
    
    function showWaitLoader(element) {
        var loader = document.getElementById('waitLoader');
        if (!loader)
            element.append('<div id="waitLoader" style="text-align:center;"></br><i class="fa fa-spinner fa-spin" style="color: #E78F08;"></i></div>');
        
        loader = $('#waitLoader');
        if (loader)
            loader.show();
    }
    
    function hideWaitLoader() {
        
        var loader = $('#waitLoader');
        if (loader)
            loader.hide();
    }
    
    return {
        init: init,
        createModule: createModule,
        sandboxes: sandboxes,
        addModulePanel: addModulePanel
    };
});