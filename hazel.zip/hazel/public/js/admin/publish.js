﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    return onPublish;

    function onPublish() {
        var element = $($('#displayPublishedDiv').html());
        var publishedModules;
        var addNewBtn = $(element.find('#addNewBtn'));
        var _loadedPublishedModule = null;
        var interactionService = core.getService('interactionService');

        addNewBtn.click(function () {
            onPublishedAddNew($($('#publishModuleDiv').html()));
        });
        
        var table = $(element.find('#dataTable'));
        
        var elements = [];
        elements.push({ configElement: 'moduleMappingConfigList', name : [] });

        core.getService('configService').getConfig(elements, function (data) {
            if (data.length > 0) {
                
                var valueArray = data[0].value;
                publishedModules = valueArray;                                

                for (var i = 0; i < valueArray.length; i++) {
                    (function (item) {
                        $('<tr/>')
						.append($('<td/>').text(item.name))
						.append($('<td/>').text(item.value.ModuleName))
                        .append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onPublishedEdit(item) })))
						.append($('<td>').append($('<button/>').text('Delete').addClass('icon fa-trash').click(function () { onPublishedDelete(item) })))
						.appendTo(table);
                    })(valueArray[i]);
                }
            }
        });
        
        function onPublishedAddNew(createElement, dataLoadedCallback) {
            element.hide();
            $('#contentDiv').append(createElement);
            
            var select = $(createElement.find($('#moduleOptions')));
            //select.append($('<option/>').attr("value", 'default').text('Select a module'));
            select.focus();
            core.getService('configService').getRegisteredModules(function (data) {
                
                //clear the option list
                select[0].options.length = 0;
                
                //add default option item
                select.append($('<option/>').attr("value", '').text('Select a module'));
                
                for (var i = 0; i < data.length; i++) {
                    select.append($("<option/>").attr("value", data[i].path).text(data[i].name));
                }
                if(dataLoadedCallback)
                    dataLoadedCallback();
            }, function (jqXHR, textStatus, errorThrown) {
                
                console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);

            });
            
            $(createElement.find('#btnPublishModuleSave')).click(function () {
                if(common.validate(createElement))
                    end(false)
            });
            $(createElement.find('#btnPublishModuleClose')).click(function () {
                end(true)
            });
            
            $(createElement.find($('#moduleOptions'))).change(function (e) {
                var propEditor = createElement.find('#propertyEditor').empty();
                
                var combo = select[0];
                
                var moduleName = combo.options[combo.selectedIndex].text;
                var packageFilePath = combo.options[combo.selectedIndex].value;
                
                if (packageFilePath !== '') {
                    
                    var moduleRegitryUri = environmentSettings.moduleRegistryPath;
                    require([moduleRegitryUri + packageFilePath + '.js'], function (loadedModule) {
                        propEditor.html('');
                        var moduleInstance = new loadedModule();
                        
                        if (moduleInstance.renderEditor)
                            moduleInstance.renderEditor($("#propertyEditor"));
                        else
                            propEditor.html('The module does not have a property editor.')
                        
                        _loadedPublishedModule = moduleInstance;
                    }, function (error) {
                        propEditor.html('Module Load Error:<br/>' + error)
                    });
                }
            });
            
            function end(isCancelled) {
                if (!isCancelled) {
                    
                    if (_loadedPublishedModule != null) {
                        
                        var combo = select[0];
                        
                        var moduleName = combo.options[combo.selectedIndex].text;
                        var packageFilePath = combo.options[combo.selectedIndex].value;
                        
                        if (packageFilePath !== '') {
                                                        
                            
                            var publishName = $(createElement.find($('#txtPublishedName'))).val();
                            var keywords = $(createElement.find($('#txtPublishedKeyword'))).val();
                            var moduleConfig = {};
                            if (_loadedPublishedModule.getSettings)
                                moduleConfig = _loadedPublishedModule.getSettings();
                            
                            var data = [{
                                    name: 'moduleConfig',
                                    value: [{
                                            name: publishName,
                                            value: {
                                                panel: {}, // panel is always null at this point
                                                module: moduleConfig,
                                                keywords: keywords
                                            }
                                        }],                                
                                },
                                {
                                    name: 'moduleMappingConfigList',
                                    value: [{
                                            name: publishName,
                                            value: {
                                                ModuleName: moduleName,
                                                path: packageFilePath
                                            }
                                        }]
                                }];
                            
                            core.getService('configService').saveModule({ data: data },
								function (data, status, xhr) {
                                if (xhr.status === 200) {
                                    console.log('Module published successfully.');
                                    interactionService.showNotification('Publish Module', 'Module published successfully.');
                                }
                                if (xhr.status === 304) {
                                    console.log('config not written. published module name exists.');
                                    interactionService.showNotification('Publish Module', 'Config not written. published module name exists.');
                                }
                            }, function (jqXHR, textStatus, errorThrown) {
                                console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);
                                interactionService.showNotification('Publish Module', 'Error while publishing.');
                            });
                            onPublish();
                        }
                    } else {
                        interactionService.showNotification('Publish', 'Please select valid module.');
                    }

                } else {
                    createElement.remove();
                    element.show();
                }
            }
        }
        
        function onPublishedDelete(row) {
            common.confirm('Are you sure you want to delete?', function () { 
                core.getService('configService').deleteModule(row, function () {
                    console.log('module deleted');
                    interactionService.showNotification('Publish', 'Published module deleted.');
                    onPublish();
                }, 
                function () {
                    console.log('module cannot be deleted');
                    interactionService.showError('Publish', 'Published module not deleted.');
                    onPublish();
                });
            });
        }
        
        function onPublishedEdit(item){
            var createElement = $($('#publishModuleDiv').html());

            onPublishedAddNew(createElement, editDataLoaded);            
            
            createElement.find('#txtPublishedName').val(item.name).prop('disabled', true);
            createElement.find('#txtPublishedKeyword').val(item.keywords).focus();
            
            var elements = [];
            elements.push({ configElement: 'moduleConfig', name : [] });

            //for setting keywords
            core.getService('configService').getConfig(elements, function (data) {
                
                if (data.length > 0) {
                    var valueArray = data[0].value;
                    for (var i = 0; i < valueArray.length; ++i) {
                        if (valueArray[i].name === item.name)
                            createElement.find('#txtPublishedKeyword').val(valueArray[i].value.keywords);
                    }
                }
            });

            function editDataLoaded() {
                var jsel = createElement.find('#moduleOptions');
                var sel = jsel[0];
                for (var i = 0; i < sel.options.length; i++) {
                    if (sel.options[i].text === item.value.ModuleName) {
                        sel.selectedIndex = i;
                        jsel.trigger('change');
                        jsel.prop('disabled', 'true');
                        break;
                    }
                }
            }
        }

        common.replaceContent(element);
    }
})