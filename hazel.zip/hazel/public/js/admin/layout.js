﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    return onLayout;
    
    function onLayout() {

        var element = $($('#displayLayoutDiv').html());
        var interactionService = core.getService('interactionService');

        // add new button
        $(element.find('#addNewBtn')).click(function (){
            onLayoutCreate($($('#createLayoutDiv').html()));
        })
        
        var table = $(element.find('#dataTable'));
        core.getService('configService').getAllLayouts(function (data) {
            for (var i = 0; i < data.length; i++) {
                (function (item) {
                    $('<tr/>')
						.append($('<td/>').text(item))
						.append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onEdit(item) })))
                        .append($('<td>').append($('<button/>').text('Delete').addClass('icon fa-trash').click(function () { onDelete(item) })))
						.appendTo(table);
                })(data[i]);
            }
        });        

        common.replaceContent(element);

        function onLayoutCreate(createElement){
            element.hide();
            $('#contentDiv').append(createElement);
            $(createElement.find("#txtApplicationUrl")).focus();
            $(createElement.find('#btnCreateLayoutOk')).click(function () {
                if (common.validate(createElement)) {
                    var app = $(createElement.find("#txtApplicationUrl")).val();
                    var layout = $(createElement.find("#txtLayoutName")).val();
                    openLayoutPage(app, layout);
                }
            });
            $(createElement.find('#btnCreateLayoutClose')).click(function () {
                createElement.remove();
                element.show();
            });
        }
        
        function onEdit(item){
            openLayoutPage('', item);
        }

        function onDelete(item){
            common.confirm('Are you sure you want to delete?', function() { 
                core.getService('configService').deleteConfig({ configElement: 'layouts', name: item }, 
                function () {
                    console.log('layout deleted');
                    interactionService.showNotification('Layout', 'Layout deleted.')
                    onLayout();
                },
                function () {
                    console.log('unable to delete layout');
                    interactionService.showError('Unable to delete layout.')
                });
            });
        }

        function openLayoutPage(appName, layoutName){ 
            var url = "index?applicationurl=" + encodeURIComponent(appName) + "&userMode=admin" + "&layoutName=" + encodeURIComponent(layoutName);
            window.open(url);
        }
    }
});
