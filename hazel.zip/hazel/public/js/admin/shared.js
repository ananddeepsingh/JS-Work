﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    return onShared;

    function onShared() {
        var element = $($('#displaySharedDiv').html());
        
        var addNewBtn = $(element.find('#addNewBtn'));
        addNewBtn.click(function () {
            onSharedAddNew($($('#registerSharedDiv').html()), null);
        });
        
        var table = $(element.find('#dataTable'));
        core.getService('configService').getAllShared(function (data) {
            if (data.length > 0) {
                var valueArray = data[0].value;
                for (var i = 0; i < valueArray.length; i++) {
                    (function (item) {
                        $('<tr/>')
						.append($('<td/>').text(item.name))
						.append($('<td/>').text(item.value.version))
						.append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onSharedEdit(item) })))
						.appendTo(table);
                    })(valueArray[i]);
                }
            }
        });
        
        function onSharedAddNew(createElement, row) {

            element.hide();
            $('#contentDiv').append(createElement);
            $(createElement.find('#sh_name')).focus();
            $(createElement.find('#btnUploadShared')).click(function () {
                if(common.validate(createElement))
                    end(false, row)
            });
            $(createElement.find('#btnCancelShared')).click(function () {
                end(true)
            });
            
            function end(isCancelled) {
                if (!isCancelled) {
                    var fd = new FormData();
                    fd.append('file', $('#sh_file')[0].files[0]);
                    fd.append('name', $('#sh_name').val());
                    fd.append('version', $('#sh_version').val());
                    fd.append('keyword', $('#sh_keyword').val());
                    fd.append('filename', row ? row.value.filename :'');
                    
                    core.getService('configService').uploadShared(fd,
						function (data) {
                        core.getService('interactionService').showNotification('Shared', 'upload success.');
                        onShared();
                    },
						function (e) {
                        core.getService('interactionService').showError('Shared', 'upload failed.');
                        onShared();
                    });

                } else {
                    createElement.remove();
                    element.show();
                }
            }
        }
        
        function onSharedEdit(row) {

            var createElement = $($('#registerSharedDiv').html());
            onSharedAddNew(createElement, row);
            $(createElement.find('#sh_version')).focus();
            $(createElement.find('#sh_name')).val(row.name).prop('disabled', true);
            $(createElement.find('#sh_version')).val(row.value.version);
            $(createElement.find('#sh_keyword')).val(row.value.keyword);
        }
                
        common.replaceContent(element);
    }
})