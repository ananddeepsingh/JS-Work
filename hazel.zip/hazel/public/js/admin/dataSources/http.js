﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    
    var _dataSourcesTable;
    var _queryParametersTable;
    var _operationParametersTable;
    var _isNewDataSource = true;
    
    var configService;
    var interactionService;
    
    var envOpts;
    var currentEditRowData;
    var prevVal;
    
    function onDisplay() {
        var element = $($('#dataSourceDiv').html());
        
        common.replaceContent(element);
        
        configService = core.getService('configService');
        interactionService = core.getService('interactionService');
        
        _dataSourcesTable = element.find("#dataSourcesTable")[0];
        _queryParametersTable = element.find("#parametersTable")[0];
        _operationParametersTable = element.find("#operationParametersTable")[0];
        
        element.find('#btnCreateDatasourceOk').click(function () {
            onDataSourceSave();
        });
        
        element.find('#btnCreateDatasourceClose').click(function () {
            onAddEditDataSourceClose();
        });
        
        element.find('#btnAddNewDataSource').click(function () {
            onAddNewDataSource();
        });
        
        element.find('#btnAddNewParameter').click(function () {
            onAddNewParameter(_queryParametersTable);
        });
        
        element.find('#btnAddNewOperationParameter').click(function () {
            onAddNewParameter(_operationParametersTable);
        });
        
        envOpts = element.find('#dataSourceEnv');
        $.map(common.getEnviroments(), function (val) {
            envOpts.append($('<option/>').text(val));
        });
        
        // handle option change
        prevVal = envOpts.val();

        envOpts.change(function () {
            currentEditRowData.name = $('#txtDatasourceName').val();
            currentEditRowData.value = currentEditRowData.value || {
                type: 'http'
            };
            currentEditRowData.value[prevVal] = {
                hostUrl: $('#txtHostUrl').val(),
                requestGenerator: $('#encoderOptions').val(),
                decoder: $('#decoderOptions').val(),
                decodeChunks: $('#chkDecodeChunks').prop('checked'),
                operation: $('#txtOperation').val(),
                queryParameters: getDatasourceParameters(_queryParametersTable),
                operationParameters: getDatasourceParameters(_operationParametersTable)
            };
            
            prevVal = envOpts.val();
            
            var dataSourceConfig = currentEditRowData.value[prevVal] || {};
            $('#txtHostUrl').val(dataSourceConfig.hostUrl);
            
            loadEncoders(dataSourceConfig.requestGenerator);
            loadDecoders(dataSourceConfig.decoder);
            
            $('#chkDecodeChunks').prop('checked', dataSourceConfig.decodeChunks);
            $('#txtOperation').val(dataSourceConfig.operation);
            setDataSourceParameters(dataSourceConfig.queryParameters, _queryParametersTable);
            setDataSourceParameters(dataSourceConfig.operationParameters, _operationParametersTable);
        });
        
        onCreateDatasource();
    }
    
    function resetCreateDataSourceToDefault() {
        
        var addEditDataSourceDiv = document.getElementById('addEditDataSourceDiv');
        
        $(addEditDataSourceDiv).find('input:text, input:password, input:file, textarea')
        .each(function () {
            $(this).val('');
        });
        
        //remove validation
        var fields = $(addEditDataSourceDiv).find('[data-validate]').removeClass('invalid');
        envOpts[0].selectedIndex = 0;
        prevVal = envOpts.val();

        resetDataSourceParameterTable(_queryParametersTable);
        resetDataSourceParameterTable(_operationParametersTable);
        hide('addEditDataSourceDiv');
    }
    
    function onCreateDatasource() {
        
        _isNewDataSource = true;
        resetDataSourcesTable();
        showDataSources();
        resetVisiblity();
        
        document.getElementById('createDatasourceDiv').style.display = 'block';
    }
    
    function onDataSourceSave() {
        
        var dsName = $('#txtDatasourceName').val();
        envOpts.change(); //fire change to get latest config values
        if (isDataSourceExists(dsName)) {
            
            var configElement = [{
                    name: 'dataSourceList',
                    value: [currentEditRowData]
                    /*value: [{
                            name: dsName,
                            value: {
                                type: 'http',
                                hostUrl: $('#txtHostUrl').val(),
                                requestGenerator: $('#encoderOptions').val(),
                                decoder: $('#decoderOptions').val(),
                                decodeChunks: $('#chkDecodeChunks').prop('checked'),
                                operation: $('#txtOperation').val(),
                                queryParameters: getDatasourceParameters(_queryParametersTable),
                                operationParameters: getDatasourceParameters(_operationParametersTable)
                            }
                        }]*/
                }];
            
            
            //if (dataSourceConfigSettings.name === '' || dataSourceConfigSettings.value.hostUrl === '' || dataSourceConfigSettings.value.queryParameters === null) {
            //    console.log('Please input all required fields.');
            //    return;
            //}
            
            if (!common.validate($('#addEditDataSourceDiv')) || configElement[0].value[0].queryParameters === null) {
                return;
            }
            
            configService.saveConfig(configElement,
                        function (responseData) {
                console.log(responseData.message);
                resetCreateDataSourceToDefault();
                onCreateDatasource();
                
                console.log('DataSource created successfully.');
                interactionService.showNotification('DataSource', 'DataSource created successfully.')
            },
                        function (jqXHR, textStatus, errorThrown) {
                console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);
            });
        }
        else {
            interactionService.showError('Datasource Error', 'Datasource with name ' + dsName + ' already exists.');
        }
    }
    
    function isDataSourceExists(dataSourceName) {
        if (!_isNewDataSource) {
            return true;
        }
        else {
            var result = $.grep(_dataSourcesTable.rows, function (e) { return e.cells[0].innerText === dataSourceName; });
            if (result !== null && result.length > 0) {
                return false;
            }
            else {
                return true;
            }
        }
    }
    
    function getDatasourceParameters(table) {
        
        var parameters = {};
        
        var rowsCount = table.rows.length;
        if (rowsCount > 1) {
            for (var index = 1; index < rowsCount; ++index) {
                var current = table.rows[index];
                
                var name = current.cells[0].innerText.trim();
                if (name === '') {
                    interactionService.showError('Datasource Error', 'Please enter parameter name.');
                    return null;
                }
                
                var value = current.cells[1].innerText.trim();
                var type = current.cells[2].childNodes[0].value;
                if (type === 'Date' && !isValidDate(value)) {
                    interactionService.showError('Datasource Error', 'Please enter valid date value for parameter [' + name + '].');
                    return null;
                }
                else if (type === 'Number') {
                    value = parseFloat(value);
                }
                parameters[name] = { value: value, type: type };
            }
        }
        
        return parameters;
    }
    
    function setDataSourceParameters(parameters, table) {
        
        resetDataSourceParameterTable(table);
        
        for (var current in parameters) {
            if (parameters.hasOwnProperty(current)) {
                
                var rowsCount = table.rows.length;
                if (rowsCount >= 1) {
                    
                    addDataSourceParameterTableRow(table, rowsCount, current, parameters[current].value, parameters[current].type);
                }
            }
        }
    }
    
    function getBtn(table) {
        return $('<button/>').click(function () {
            deleteParameterRow(this, table);
        }).addClass('icon fa-trash').text('Delete');
    }
    
    function addDataSourceParameterTableRow(table, index, cellValue1, cellValue2, cellValue3) {
        var row = table.insertRow(index);
        
        var cell1 = row.insertCell(0);
        cell1.innerHTML = cellValue1;
        var cell2 = row.insertCell(1);
        cell2.innerHTML = cellValue2;
        
        var cell3 = row.insertCell(2);
        cell3.innerHTML = '<select id="dataType"><option value="String" selected="selected">String</option>' +
                                  '<option value="Number">Number</option><option value="Date">Date</option></select>';
        if (typeof cellValue3 !== 'undefined') {
            cell3.childNodes[0].value = cellValue3;
        }
        var cell4 = row.insertCell(3);
        
        var button = $('<button/>').click(function () {
            var r = row;
            deleteParameterRow(r, table);
        }).addClass('icon fa-trash').text('Delete');
        
        
        //cell4.innerHTML = '<button onclick="deleteParameterRow(this, table)" class="icon fa-trash">Delete</button>';
        $(cell4).append(getBtn(table));
        cell1.setAttribute("contenteditable", "true");
        cell2.setAttribute("contenteditable", "true");
        
        cell1.setAttribute("required", "");
        cell2.setAttribute("required", "");
        cell1.setAttribute("data-validate", "");
        cell2.setAttribute("data-validate", "");
    }
    
    function addDataSourceTableRow(index, cellValue1, cellValue2) {
        
        var row = _dataSourcesTable.insertRow(index);
        
        var cell1 = row.insertCell(0);
        cell1.innerHTML = cellValue1;
        var cell2 = row.insertCell(1);
        $(cell2).append($('<button/>').addClass('icon fa-edit').click(function () {
            editDataSourceRow(JSON.parse(this.parentNode.parentNode.cells[3].innerText));
        }).text('Edit'));
        var cell3 = row.insertCell(2);
        $(cell3).append($('<button/>').addClass('icon fa-trash').click(function () {
            deleteDataSourceRow(this)
        }).text('Delete'));
        var cell4 = row.insertCell(3);
        cell4.innerHTML = cellValue2;
        cell4.setAttribute("style", "display:none;");
    }
    
    function resetDataSourceParameterTable(table) {
        
        if (table !== null) {
            var rowsCount = table.rows.length;
            if (rowsCount > 1) {
                for (var index = rowsCount - 1; index >= 1; index--) {
                    table.deleteRow(index);
                }
            }
        }
    }
    
    function resetDataSourcesTable() {
        
        if (_dataSourcesTable !== null) {
            var rowsCount = _dataSourcesTable.rows.length;
            if (rowsCount > 1) {
                for (var index = rowsCount - 1; index >= 1; index--) {
                    _dataSourcesTable.deleteRow(index);
                }
            }
        }
    }
    
    function showDataSources() {
        
        var elements = [];
        elements.push({ configElement: 'dataSourceList', name: [] });
        
        configService.getConfig(elements,
                    function (responseData) {
            if (responseData.length > 0) {
                for (var index = 0; index < responseData[0].value.length; index++) {
                    if (responseData[0].value[index].value.type === 'http')
                        addDataSourceTableRow(_dataSourcesTable.rows.length, responseData[0].value[index].name, JSON.stringify(responseData[0].value[index]));
                }
            }
        },
                    function (jqXHR, textStatus, errorThrown) {
            console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);
        });
    }
    
    function onAddNewParameter(table) {
        
        var rowsCount = table.rows.length;
        if (rowsCount >= 1) {
            
            addDataSourceParameterTableRow(table, rowsCount, '', '');
        }
    }
    
    function onAddNewDataSource() {
        currentEditRowData = {};
        document.getElementById("txtDatasourceName").disabled = false;
        pop('addEditDataSourceDiv');
        document.getElementById('txtDatasourceName').focus();
        
        loadEncoders();
        loadDecoders();
    }
    
    function loadEncoders(selectedValue) {
        configService.getEncoders(function (data) {
            
            var encoderOptions = $('#encoderOptions');
            
            //clear the option list
            encoderOptions[0].options.length = 0;
            
            //add default option item
            encoderOptions.append($('<option/>').attr("value", '').text('---Select Encoder---'));
            
            for (var i = 0; i < data.length; i++) {
                encoderOptions.append($("<option/>").attr("value", data[i]).text(data[i]));
            }
            
            if (selectedValue != null && typeof selectedValue != 'undefined')
                encoderOptions.val(selectedValue);


        }, function (jqXHR, textStatus, errorThrown) {
            
            console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);

        });
    }
    
    function loadDecoders(selectedValue) {
        configService.getDecoders(function (data) {
            
            var decoderOptions = $('#decoderOptions');
            
            //clear the option list
            decoderOptions[0].options.length = 0;
            
            //add default option item
            decoderOptions.append($('<option/>').attr("value", '').text('---Select Decoder---'));
            
            for (var i = 0; i < data.length; i++) {
                decoderOptions.append($("<option/>").attr("value", data[i]).text(data[i]));
            }
            
            if (selectedValue != null && typeof selectedValue != 'undefined')
                decoderOptions.val(selectedValue);

        }, function (jqXHR, textStatus, errorThrown) {
            
            console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);

        });
    }
    
    function onAddEditDataSourceClose() {
        
        resetCreateDataSourceToDefault();
        onCreateDatasource();
    }
    
    function deleteParameterRow(currentRow, table) {
        var index = currentRow.parentNode.parentNode.rowIndex;
        table.deleteRow(index);
    }
    
    function deleteDataSourceRow(currentRow) {
        
        var deleteConfirmResult = confirm("Are you sure, you want to delete?");
        if (deleteConfirmResult) {
            var parentNode = currentRow.parentNode.parentNode;
            
            var dataSourceConfigSettings = {
                configElement: 'dataSourceList',
                name: parentNode.cells[0].innerText
            };
            
            configService.deleteConfig(dataSourceConfigSettings,
                        function (responseData) {
                console.log(responseData.message);
                resetCreateDataSourceToDefault();
            },
                        function (jqXHR, textStatus, errorThrown) {
                console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);
            });
            
            _dataSourcesTable.deleteRow(parentNode.rowIndex);
        }
    }
    
    function editDataSourceRow(currentRow) {
        
        _isNewDataSource = false;
        
        pop('addEditDataSourceDiv');
        document.getElementById('txtHostUrl').focus();
        document.getElementById("txtDatasourceName").disabled = true;
        
        /* FOR BACKWARD COMPATIBLITY:*/        
        if (currentRow.value.hostUrl && currentRow.value.operation && currentRow.value.decoder && currentRow.value.requestGenerator) {
            var r = {
                name: currentRow.name,
                value: {
                    type: 'http',
                    dev: {
                        hostUrl: currentRow.value.hostUrl,
                        requestGenerator: currentRow.value.requestGenerator,
                        decoder: currentRow.value.decoder,
                        decodeChunks: currentRow.value.decodeChunks,
                        operation: currentRow.value.operation,
                        queryParameters: currentRow.value.queryParameters,
                        operationParameters: currentRow.value.operationParameters
                    }
                }
            }
            currentRow = r;
        }
        /*BACKWARD COMP. ENDS*/

        currentEditRowData = currentRow;
        
        var dataSourceConfig = currentEditRowData.value[envOpts.val()];
        
        document.getElementById('txtDatasourceName').value = currentRow.name;
        document.getElementById('txtHostUrl').value = dataSourceConfig.hostUrl;
        
        loadEncoders(dataSourceConfig.requestGenerator);
        loadDecoders(dataSourceConfig.decoder);
        
        document.getElementById('chkDecodeChunks').checked = dataSourceConfig.decodeChunks;
        document.getElementById('txtOperation').value = dataSourceConfig.operation;
        setDataSourceParameters(dataSourceConfig.queryParameters, _queryParametersTable);
        setDataSourceParameters(dataSourceConfig.operationParameters, _operationParametersTable);

    }
    
    function pop(div) {
        document.getElementById(div).style.display = 'block';
    }
    
    function resetVisiblity() {
        // set all divs under #contentDiv to none
        $('#contentDiv>div').hide();
    }
    
    function hide(div) {
        document.getElementById(div).style.display = 'none';
    }
    
    function isValidDate(date) {
        return ((new Date(date) !== "Invalid Date" && !isNaN(new Date(date))));
    }
    
    return onDisplay;
})