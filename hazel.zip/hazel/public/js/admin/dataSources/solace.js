﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    return onDisplay;
    
    function onDisplay() {
        var element = $($('#displaySolaceDatasourceDiv').html());
        
        var addNewBtn = element.find('#addNewBtn');
        addNewBtn.click(function () {
            onAddNew($($('#addSolaceDatasourceDiv').html()), null);
        });
        
        var elements = [];
        elements.push({ configElement: 'dataSourceList', name : [] });
        
        var table = element.find('#dataTable');
        core.getService('configService').getConfig(elements, function (data) {
            if (data.length > 0) {
                
                var valueArray = data[0].value;
                for (var i = 0; i < valueArray.length; i++) {
                    if (valueArray[i].value.type === 'solace') { // add only SOLACE DS
                        (function (item) {
                            $('<tr/>')
						.append($('<td/>').text(item.name))
						.append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onEdit(item) })))
                        .append($('<td>').append($('<button/>').text('Delete').addClass('icon fa-trash').click(function () { onDelete(item) })))
						.appendTo(table);
                        })(valueArray[i]);
                    }
                }
            }
        });
        
        function onAddNew(createElement, row) {
            
            element.hide();
            $('#contentDiv').append(createElement);
            createElement.find('#txtDatasourceName').focus();
            createElement.find('#btnCreateDatasourceOk').click(function () {
                if (common.validate(createElement))
                    end(false, row)
            });
            createElement.find('#btnCreateDatasourceClose').click(function () {
                end(true)
            });
            
            // handle enviroment
            var envOpts = createElement.find('#dataSourceEnv');
            $.map(common.getEnviroments(), function (val) {
                envOpts.append($('<option/>').text(val));
            });
            var prevVal = envOpts.val();
            
            var data = (row && row.value) || {
                type: 'solace'
            };
            
            envOpts.change(function () {
                var curVal = envOpts.val();
                //save settings of prev value
                data[prevVal] = {
                    url: createElement.find('#txtHostUrl').val(),
                    topic: createElement.find('#txtTopic').val(),
                    subscribe: createElement.find('#chkSubscribe').prop('checked'),
                    vpn: createElement.find('#txtVpn').val(),
                    cacheName: createElement.find('#txtCacheName').val(),
                    action: createElement.find('#drpAction').val(),
                    snapCache: createElement.find('#chkCacheSnap').prop('checked'),
                }
                
                // if curVal exists set the props of this setting else set to null
                if (data[curVal]) {
                    var cur = data[curVal];
                    createElement.find('#txtHostUrl').val(cur.url);
                    createElement.find('#txtTopic').val(cur.topic);
                    createElement.find('#txtVpn').val(cur.vpn);
                    createElement.find('#txtCacheName').val(cur.cacheName);
                    createElement.find('#drpAction').val(cur.action);
                    createElement.find('#chkSubscribe').prop('checked', cur.subscribe);
                    createElement.find('#chkCacheSnap').prop('checked', cur.snapCache);
                } else {
                    createElement.find('#txtHostUrl').val('');
                    createElement.find('#txtTopic').val('');
                    createElement.find('#txtVpn').val('');
                    createElement.find('#txtCacheName').val('');
                    createElement.find('#drpAction').val(3);
                    createElement.find('#chkSubscribe').prop('checked', false);
                    createElement.find('#chkCacheSnap').prop('checked', false);
                }
                
                // update prev val
                prevVal = curVal;
            });
            
            
            function end(isCancelled) {
                if (!isCancelled) {
                    /*var data = {
                        type: 'solace',
                        url: createElement.find('#txtHostUrl').val(),
                        topic: createElement.find('#txtTopic').val(),
                        subscribe: createElement.find('#chkSubscribe').prop('checked'),
                        vpn: createElement.find('#txtVpn').val(),
                        cacheName: createElement.find('#txtCacheName').val(),
                        action: createElement.find('#drpAction').val(),
                        snapCache: createElement.find('#chkCacheSnap').prop('checked'),
                    };*/
                    envOpts.change();
                    var configElement = [{
                            name: 'dataSourceList', 
                            value: [{
                                    name: createElement.find('#txtDatasourceName').val(), 
                                    value: data
                                }]
                        }];
                    
                    var elements = [];
                    elements.push({ configElement: 'dataSourceList', name : [createElement.find('#txtDatasourceName').val()] });
                    
                    //if NOT in edit mode and if value for this config found, do not add
                    core.getService('configService').getConfig(elements, function (data) {
                        if (createElement.find('#txtDatasourceName').prop('disabled') === false && data[0].value.length > 0)
                            core.getService('interactionService').showError('Data Source', 'data source with duplicate name cannot be created.');
                        else {
                            core.getService('configService').saveConfig(configElement,
						    function (data) {
                                core.getService('interactionService').showNotification('Solace', 'created success.');
                                onDisplay();
                            },
						    function (e) {
                                core.getService('interactionService').showError('Solace', 'creation failed.');
                                onDisplay();
                            });
                        }
                    }, function () {
                        core.getService('interactionService').showError('Data Source', 'erro reading data');
                    });
                } else {
                    createElement.remove();
                    element.show();
                }
            }
        }
        
        function onEdit(row) {
            
            var createElement = $($('#addSolaceDatasourceDiv').html());
            
            /*FOR BACKWARD COMPATIBLITY ONLY*/
            if (row.value.hasOwnProperty('action') 
                && row.value.hasOwnProperty('cacheName') 
                && row.value.hasOwnProperty('subscribe') 
                && row.value.hasOwnProperty('topic') 
                && row.value.hasOwnProperty('url')) {
                row = {
                    value: {
                        dev: {
                            action: row.value.action,
                            cacheName: row.value.cacheName,
                            url: row.value.url,
                            topic: row.value.topic,
                            vpn: row.value.vpn,
                            subscribe: row.value.subscribe,
                            snapCache: row.value.snapCache,
                        },
                        type: 'solace'
                    },                    
                    name: row.name
                }
            }
            /*BACKWARD COMPT. ENDS*/

            onAddNew(createElement, row);
            
            createElement.find('#txtDatasourceName').val(row.name).prop('disabled', true);
            
            var curVal = createElement.find('#dataSourceEnv').val();
            var cur = row.value[curVal];
            if (cur) {
                createElement.find('#txtHostUrl').val(cur.url);
                createElement.find('#txtTopic').val(cur.topic);
                createElement.find('#txtVpn').val(cur.vpn);
                createElement.find('#txtCacheName').val(cur.cacheName);
                createElement.find('#drpAction').val(cur.action);
                createElement.find('#chkSubscribe').prop('checked', cur.subscribe);
                createElement.find('#chkCacheSnap').prop('checked', cur.snapCache);
            }
        }
        
        function onDelete(row) {
            common.confirm('Are you sure you want to delete?', function () {
                core.getService('configService').deleteConfig({
                    configElement: 'dataSourceList',
                    name: row.name,
                }, function () {
                    core.getService('interactionService').showNotification('Solace', 'config deleted.');
                    onDisplay();
                }, 
                function () {
                    core.getService('interactionService').showError('Solace', 'config not deleted.');
                    onDisplay();
                });
            });
        }
        
        common.replaceContent(element);
    }
})