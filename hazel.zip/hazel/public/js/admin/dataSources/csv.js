﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {        

    return onDisplay;
    
    function onDisplay() {
        var element = $($('#displayCSVDatasourceDiv').html());
        
        var interactionService = core.getService('interactionService');
        var notificationTitle = 'CSV';
        
        var addNewBtn = element.find('#addNewBtn');
        addNewBtn.click(function () {
            onAddNew($($('#addCSVDatasourceDiv').html()), null);
        });
        
        var elements = [];
        elements.push({ configElement: 'dataSourceList', name : [] });
        
        var table = element.find('#dataTable');
        core.getService('configService').getConfig(elements, function (data) {
            if (data.length > 0) {
                
                var valueArray = data[0].value;
                for (var i = 0; i < valueArray.length; i++) {
                    if (valueArray[i].value.type === 'csv') { // add only SOLACE DS
                        (function (item) {
                            $('<tr/>')
						.append($('<td/>').text(item.name))
						.append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onEdit(item) })))
                        .append($('<td>').append($('<button/>').text('Delete').addClass('icon fa-trash').click(function () { onDelete(item) })))
						.appendTo(table);
                        })(valueArray[i]);
                    }
                }
            }
        });
        
        function onAddNew(createElement, row) {
            
            element.hide();
            $('#contentDiv').append(createElement);
            createElement.find('#txtDatasourceName').focus();
            createElement.find('#btnCreateDatasourceOk').click(function () {
                if (common.validate(createElement))
                    end(false, row)
            });
            createElement.find('#btnCreateDatasourceClose').click(function () {
                end(true)
            });
            
            //createElement.find('#btnSelectFile').click(function () {
            //    var input = $(document.createElement('input'));
            //    input.attr("type", "file");
            //    input.trigger('click'); // opening dialog
                
            //    input.change(function(t){
            //        createElement.find('#txtCSVFileName').val(input[0].value);
            //    });
            //    return false;
                
            //});
            
            function end(isCancelled) {
                if (!isCancelled) {
                    var data = {
                        type: 'csv',
                        file: createElement.find('#txtCSVFileName').val(),
                    };
                    
                    var configElement = [{
                            name: 'dataSourceList', 
                            value: [{
                                    name: createElement.find('#txtDatasourceName').val(), 
                                    value: data
                                }]
                        }];
                    
                    var elements = [];
                    elements.push({ configElement: 'dataSourceList', name : [createElement.find('#txtDatasourceName').val()] });
                    
                    //if NOT in edit mode and if value for this config found, do not add
                    core.getService('configService').getConfig(elements, function (data) {
                        if (createElement.find('#txtDatasourceName').prop('disabled') === false && data[0].value.length > 0)
                            interactionService.showError(notificationTitle, 'data source with duplicate name cannot be created.');
                        else {
                            core.getService('configService').saveConfig(configElement,
						    function (data) {
                                interactionService.showNotification(notificationTitle, 'Datasource created successfully.');
                                onDisplay();
                            },
						    function (e) {
                                interactionService.showError(notificationTitle, 'Error while creating datasource.');
                                onDisplay();
                            });
                        }
                    }, function () {
                        interactionService.showError(notificationTitle, 'erro reading data');
                    });

                } else {
                    createElement.remove();
                    element.show();
                }
            }
        }
        
        function onEdit(row) {
            
            var createElement = $($('#addCSVDatasourceDiv').html());
            onAddNew(createElement, row);
            
            createElement.find('#txtDatasourceName').val(row.name).prop('disabled', true);
            createElement.find('#txtCSVFileName').val(row.value.file);
            createElement.find('#txtCSVFileName').focus();
        }
        
        function onDelete(row) {
            common.confirm('Are you sure you want to delete?', function () {
                core.getService('configService').deleteConfig({
                    configElement: 'dataSourceList',
                    name: row.name,
                }, function () {
                    interactionService.showNotification(notificationTitle, 'Datasource deleted successfully.');
                    onDisplay();
                }, 
                function () {
                    interactionService.showError(notificationTitle, 'Error while deleting datasource.');
                    onDisplay();
                });
            });
        }
        
        common.replaceContent(element);
    }
})