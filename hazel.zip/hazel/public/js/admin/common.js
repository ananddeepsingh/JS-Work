﻿"use strict";

define(['require', 'jquery'], function (require, $) {
    
    return {        
        replaceContent: function (element) {
            $('#contentDiv').empty();
            if (typeof element === 'string')
                $('#contentDiv').html(element);
            else
                $('#contentDiv').append(element);
        },

        confirm: function (message, trueCallback, falseCallback){ /*callback is passed the result of the dialog*/
            if (window.confirm(message)) {
                if (trueCallback)
                    trueCallback();
            } else {
                if (falseCallback)
                    falseCallback();
            }
        },

        validate: function (root){
            // get all elements with data-validate attr from root.
            // clear all validation fields .invalid
            // check validity.valid
            // check data-invalid-message and show it
            // if data-invalid-message not found use el.validationMessage
            var isFormValid = true;

            var fields = root.find('[data-validate]');
            fields.removeClass('invalid');
            fields.attr('title', '');
            fields.each(function (i, el) {

                if (el.validity && !el.validity.valid) {
                    
                    isFormValid = isFormValid ? false : isFormValid;
                    
                    var ele = $(el);
                    ele.addClass('invalid');

                    if (ele.attr('data-invalid-message'))
                        ele.attr('title', ele.attr('data-invalid-message'));
                    else
                        ele.attr('title', el.validationMessage);
                }
            });
            return isFormValid;
        },

        getEnviroments: function (){
            return workspaceSettings.environmentSettings.environments;
        }
    }
});
