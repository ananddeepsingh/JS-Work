﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    
    return onPromotion;
    
    function onPromotion() {
        
        var element = $($('#displayPromotionDiv').html());
        var promoteConfigBtn = $(element.find('#promoteConfigBtn'));
        
        var waitSpinner = $($('#waitSpinner').html());
        
        var promotionStatusDiv = element.find('#promotionStatusDiv');
        promotionStatusDiv.hide();
        
        var promotionStatusLabel = element.find('#promotionStatusLabel');
        
        var envOpts = element.find('#promotEnvironmentOptions');
        $.map(common.getEnviroments(), function (val) {
            envOpts.append($('<option/>').text(val));
        });

        promoteConfigBtn.click(function () {
            
            var promotionMessage = 'Selected item(s) promoted successfully.';

            var configList = element.find('#promote-config');
            
            var elements = {};

            $.each(configList.find("li"), function () {
                
                var parentElementId = $(this).parent()[0].parentNode.childNodes[0].id;
                if (this.childNodes[1].childNodes[0].checked && typeof parentElementId !== 'undefined') {
                    
                    if (typeof elements[parentElementId] === 'undefined') {
                        elements[parentElementId] = [];
                    }

                    elements[parentElementId].push({ name: this.childNodes[2].innerText, status: '' });                    
                }
            });
            
            if (Object.getOwnPropertyNames(elements).length > 0) {
                
                $('#contentDiv').append(waitSpinner);
                
                core.getService('configService').promoteElement({ elements: elements, destinationEnvironment: envOpts.val() }, function (returnElements) {
                    
                    
                    var totalItemCount = 0;
                    var failedItemcount = 0;
                    
                    $.each(configList.find("li"), function () {
                        
                        var parentElementId = $(this).parent()[0].parentNode.childNodes[0].id;
                        
                        if (this.childNodes[1].childNodes[0].checked && typeof parentElementId !== 'undefined') {
                            
                            var items = returnElements[parentElementId];
                            
                            var selectedItem = this.childNodes[2].innerText;
                            
                            var currentItem = $.grep(items, function (e) { return e.name === selectedItem; });
                            if (currentItem.length > 0) {
                                
                                $(this).removeClass('' + !currentItem[0].status);
                                $(this).addClass('' + currentItem[0].status);
                                
                                if (!currentItem[0].status)
                                    failedItemcount += 1;
                                totalItemCount += 1;
                            }
                        }
                        else if (!this.childNodes[1].childNodes[0].checked && typeof parentElementId !== 'undefined') {
                            $(this).removeClass('true');
                            $(this).removeClass('false');
                        }
                    });
                    waitSpinner.remove();
                    
                    if (failedItemcount > 0) {
                        
                        promotionMessage = failedItemcount +' item(s) failed to promote from selected ' + totalItemCount + ' item(s). Please try again.';
                    }
                    
                    promotionStatusLabel[0].innerHTML = promotionMessage;
                    promotionStatusDiv.show();
                });
            }
            else {
                promotionMessage = 'Please select item.';

                promotionStatusLabel[0].innerHTML = promotionMessage;
                promotionStatusDiv.show();
            }
        });
        
        function getStatusText(elements)
        {
            var successText = 'Below item(s) promoted successfully:';
            var failedText = 'Error in promoting below item(s). Please try again:';
            for (var current in elements) {
                var items = elements[current];
                
                var successResult = $.grep(items, function (e) { return e.status === true; });
                var faliedResult = $.grep(items, function (e) { return e.status === false; });
                
                if(successResult.length>0)
                    successText += '\n * ' + current;
                if(faliedResult.length>0)
                    failedText += '\n * ' + current;

                for (var index = 0; index < items.length; index++) {
                    if(items[index].status)
                        successText += '\n   - ' + items[index].name;
                    else {
                        failedText += '\n   - ' + items[index].name;
                    }
                }
            }    

            return successText +'\n --------------------------------------------- \n'+failedText;
        }
                
        element.find('#promote-config').delegate("label input:checkbox", "change", function () {
            var 
                checkbox = $(this),
                nestedList = checkbox.parent().next().next(),
                selectNestedListCheckbox = nestedList.find("label:not([for]) input:checkbox");
            
            if (checkbox.is(":checked")) {
                return selectNestedListCheckbox.prop("checked", true);
            }
            selectNestedListCheckbox.prop("checked", false);
        });
        
        var menuItems = [
            { "name": "moduleMappingConfigList", "text": "Modules", "handler": getPublishModules, "child": [] },
            { "name": "sharedConfig", "text": "Shared Libraries", "handler": getSharedLibraries, "child": [] },
            { "name": "layouts", "text": "Layouts", "handler": getLayouts, "child": [] },
            { "name": "dataSourceList", "text": "Datasources", "handler": getDataSources, "child": [] }
        ];
        
        var treeViewParentNode = element.find('#promote-config');
        
        for (var i = 0; i < menuItems.length; i++) {

            (function (currentItem) {                
                buildMenu(currentItem, treeViewParentNode);

            })(menuItems[i]);
        }
        
        function getRegisteredModules(element) {
            
            core.getService('configService').getRegisteredModules(function (data) {
                for (var i = 0; i < data.length; i++) {
                    (function (item) {

                        buildMenu({ "name": item.name, "text": item.name, "child": {}, "handler": "" }, element);
                        
                    })(data[i]);
                }
            });
        }
        
        function getPublishModules(element) {
            
            var elements = [];
            elements.push({ configElement: 'moduleMappingConfigList', name : [] });
            
            core.getService('configService').getConfig(elements, function (data) {
                
                if (data.length > 0) {
                    for (var i = 0; i < data[0].value.length; i++) {
                        (function (item) {
                            buildMenu({ "name": item.name, "text": item.name, "child": {}, "handler": "" }, element);
                        })(data[0].value[i]);
                    }
                }
            });
        }
        
        function getSharedLibraries(element) {
            
            core.getService('configService').getAllShared(function (data) {
                
                if (data.length > 0) {
                    var valueArray = data[0].value;
                    for (var i = 0; i < valueArray.length; i++) {
                        (function (item) {
                            buildMenu({ "name": item.name, "text": item.name, "child": {}, "handler": "" }, element);
                        })(valueArray[i]);
                    }
                }
            });
        }
        
        function getLayouts(element) {
            
            core.getService('configService').getAllLayouts(function (data) {
                
                for (var i = 0; i < data.length; i++) {
                    (function (item) {
                        buildMenu({ "name": item, "text": item, "child": {}, "handler": "" }, element);
                    })(data[i]);
                }
            });
        }
        
        function getDataSources(element) {
            
            var elements = [];
            elements.push({ configElement: 'dataSourceList', name : [] });
            
            core.getService('configService').getConfig(elements, function (data) {
                if (data.length > 0) {
                    for (var i = 0; i < data[0].value.length; i++) {
                        (function (item) {
                            buildMenu({ "name": item.name, "text": item.name, "child": {}, "handler": "" }, element);
                        })(data[0].value[i]);
                    }
                }
            });
        }
        
        function buildMenu(currentItem, parentElement) {
            
            //$('<input type="checkbox" id="node-0-0-0-1" /><label><input type="checkbox" /><span></span></label><label for="node-0-0-0-1">'+ currentItem.text+'</label>')
            //.appendTo($('<li/>').click(currentItem.handler).appendTo(treeViewParentNode));
            
            var element = $('<li />').html('<input type="checkbox" id="' + currentItem.name + '" /><label><input type="checkbox" /><span></span></label><label for="' + currentItem.name + '">' + currentItem.text + '</label>');
            
            if (currentItem.child.length > 0) {
                
                for (var i = 0; i < currentItem.child.length; i++) {
                    
                    var childElement = $('<ul/>');
                    childElement.appendTo(element);
                    
                    (function (childItem) {
                        
                        buildMenu(childItem, childElement);
                                                
                    })(currentItem.child[i]);
                }
            }
            else if (currentItem.handler != '') {
                
                var childElement = $('<ul/>');
                childElement.appendTo(element);
                
                currentItem.handler.call('', childElement);
            }
            
            element.appendTo(parentElement);               
        }

        common.replaceContent(element);    
    }    
});