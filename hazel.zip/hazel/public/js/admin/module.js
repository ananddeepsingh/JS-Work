﻿"use strict";

define(['require', 'jquery', 'core', 'admin/common'], function (require, $, core, common) {
    
    return onModule;
    
    function onModule() {
        var element = $($('#displayModuleDiv').html());
        var interactionService = core.getService('interactionService');
        var addNewBtn = $(element.find('#addNewBtn'));
        addNewBtn.click(function () {
            onModuleCreate($($('#createModuleDiv').html()), false);
        });
        
        var table = $(element.find('#dataTable'));
        core.getService('configService').getRegisteredModules(function (data) {
            for (var i = 0; i < data.length; i++) {
                (function (item) {
                    $('<tr/>')
						.append($('<td/>').text(item.name))
						.append($('<td/>').text(item.description))
						.append($('<td/>').text(item.version))
						.append($('<td/>').text(item.path))
						.append($('<td>').append($('<button/>').text('Edit').addClass('icon fa-edit').click(function () { onModuleEdit(item) })))
						.appendTo(table);
                })(data[i]);
            }
        });
        
        function onModuleEdit(moduleRow) {
            var createElement = $($('#createModuleDiv').html());
            onModuleCreate(createElement, true);
            $(createElement.find('#txtDescription')).focus();
            $(createElement.find('#txtName')).val(moduleRow.name).prop('disabled', true);
            $(createElement.find('#txtDescription')).val(moduleRow.description);
            $(createElement.find('#txtVersion')).val(moduleRow.version);
            $(createElement.find('#txtMain')).val(moduleRow.main).prop('disabled', true);  // disable main. Must update 'moduleMappingConfigList.path' if main is to be updated
            $(createElement.find('#txtAuthor')).val(moduleRow.author);
        }
        
        function onModuleCreate(createElement, isEditMode) {
            element.hide();
            $('#contentDiv').append(createElement);
            $(createElement.find('#txtName')).focus();
            $(createElement.find('#btnConfigFormSave')).click(function () {
                end(false)
            });
            $(createElement.find('#btnConfigFormCancel')).click(function () {
                end(true)
            });
            
            function end(isCancelled) {
                
                if (!isCancelled) {
                    
                    var postData = new FormData();
                    
                    postData.append("fileToUpload", $('#file')[0].files[0]);
                    
                    var packageData = {};
                    packageData.name = $('#txtName').val();
                    packageData.description = $('#txtDescription').val();
                    packageData.version = $('#txtVersion').val();
                    packageData.main = $('#txtMain').val();
                    packageData.author = $('#txtAuthor').val();
                    
                    postData.append("packageData", JSON.stringify(packageData));
                    
                    if (common.validate(createElement)) {
                        core.getService('configService').uploadModule(postData, function (data) {
                            console.log('module uploaded success.');
                            interactionService.showNotification('Module', 'Module uploaded successfully.')
                            onModule(); // reset all and populate modules again
                        }, function (jqXHR, textStatus, errorThrown) {
                            console.log('Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText);
                            interactionService.showError('Module', 'Module upload failed');
                            onModule(); // reset all and populate modules again
                        });
                    }
                } else {
                    createElement.remove();
                    element.show();
                }
            }
        }
        common.replaceContent(element);
    }
});