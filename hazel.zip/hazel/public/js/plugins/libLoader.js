"use strict";

define({
    load: function (name, req, onload, config) {
        
        req(['core'], function (core) {
            core.getService('configService').getShared(name, function (data) {
                req(['http://localhost:5000' + data[0].value[0].value.filename], function (value) {
                    onload(value);
                });
            }, null);
        });
    }
});