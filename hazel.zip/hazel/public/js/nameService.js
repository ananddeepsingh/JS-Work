﻿"use strict";

var _counter=1;
var _seprator = '_';

define(['require'], function (require) {
    
    function getUniqueName(name, core) {

        _counter = parseInt(core.panelCounter) + 1;
        core.panelCounter = _counter;

        return (name + _seprator + _counter);
    }

    return {
        getUniqueName: getUniqueName
    };
});