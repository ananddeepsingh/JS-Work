﻿"use strict";

define(function (require) {
         
    function loadModule(core, layoutManager, Sandbox, module) {

        var sandBox = new Sandbox(core, layoutManager);
        core.sandboxes.push(sandBox);

        sandBox.init(module);

    }

    function renderModule(sandboxArray) {
        
        for (var i = 0; i < sandboxArray.length; i += 1) {
            sandboxArray[i].render();
        }
    }
    
    return {
        loadModule: loadModule
    };
});