﻿"use strict";

define(['require', 'postal/postal.min', 'layoutService', 'interactionService', 'moduleManager', 'configService', 'dataAccessService',
    'logger/logger',
    'logger/consoleListner',
    'logger/websocketListner', 'helper'],
    function (require, Postal, layoutService, interactionService, moduleManager, configService, dataAccessService, logger, loggerConsole, loggerWebsoc, helper) {

    var services = [];     

    function start(workspaceSettings, userInfo)
    {
        this.layoutService = layoutService;
        this.moduleManager = moduleManager;
        this.panelCounter = workspaceSettings.panelCounter || 1;
        this.workspaceSettings = workspaceSettings;
        this.userInfo = userInfo;
        this.helper = helper;
        registerServices(this);
    }
    
    function initLayout(){
        initilizeLayout(this);
        moduleManager.init(this, workspaceSettings.moduleList);
    }

    function registerServices(selfObject) {

        interactionService.init();
        
        addService('logger', logger);
        logger.addListner(loggerConsole);
        logger.addListner(loggerWebsoc);

        addService('pageBus', Postal);
        addService('interactionService', interactionService);

        addService('configService', configService);
        configService.init(selfObject);

        addService('dataAccessService', dataAccessService);
        dataAccessService.init(selfObject);
    }

    function initilizeLayout(core)
    {
        layoutService.init(core, workspaceSettings.moduleList);
        layoutService.restoreLayout(workspaceSettings.workspace);
    }

    function getService(serviceName) {
        var i;
        for (i = 0; i < services.length; i+=1) {
            if (serviceName === services[i].name) {
                return services[i].implementation;
            }
        }
    }

    function addService(serviceName, implementaion) {
        services.push({
            name: serviceName,
            implementation: implementaion
        });
    }
    
    return {
        start: start,
        getService: getService,
        addService: addService,
        initLayout: initLayout
    };
});