﻿"use strict";

define(['require'], function (require) {
    
    var _core;
    var _logger;
    var _configurationServicePath;
    var _moduleRegistryServicePath;
    
    function requestService(uri, methodType, data, contentType, processData) {
        processData = typeof processData !== 'undefined' ? processData : true;
        contentType = typeof contentType !== 'undefined' ? contentType : 'application/json';
        data = processData ? JSON.stringify(data) : data;

        return $.ajax({
            type: methodType || 'GET',
            url: uri,
            dataType: 'json',
            contentType: contentType,
            data: data,
            processData: processData

        }).fail(function (jqXHR, textStatus, errorThrown) {
            
            _logger.write({
                type: 'ERROR',
                message: 'Status:' + jqXHR.status + ', Error:' + errorThrown + ', Response Text:' + jqXHR.responseText,
                moduleName: 'Config Service'
            });

        }).done(function (data) {
            
            _logger.write({
                type: 'INFO',
                message: 'Response recevied.',
                moduleName: 'Config Service'
            });
            
            return data;
        });
    }
    
    function getRequestData(data)
    {
        var userName = _core.userInfo.userMode !== 'admin' ? (_core.userInfo.userMode === 'impersonate' ? _core.userInfo.impersonatedUserName : _core.userInfo.userName) : null;

        var requestData = {
            userDetail: { userName: userName },
            data : data
        }

        return requestData;
    }
    
    return {
        
        init: function (core) {
            _core = core;
            _logger = _core.getService('logger');
            _configurationServicePath = _core.workspaceSettings.environmentSettings.configurationServicePath;
            _moduleRegistryServicePath = _core.workspaceSettings.environmentSettings.moduleRegistryServicePath;
        },
        
        saveConfig: function (configElement, successCallback, failedCallback){

            var saveLayoutUri = 'saveConfig';
            requestService(_configurationServicePath+saveLayoutUri, 'POST', getRequestData(configElement)).done(successCallback).fail(failedCallback);
        },
        
        deleteConfig: function (configElement, successCallback, failedCallback) {

            var deleteLayoutUri = 'deleteConfig';
            requestService(_configurationServicePath+deleteLayoutUri, 'DELETE', getRequestData(configElement)).done(successCallback).fail(failedCallback);
        },
        
        getConfig: function (configElement, successCallback, failedCallback) {

            var getLayoutUri = 'getConfig';
            requestService(_configurationServicePath+getLayoutUri, 'POST', getRequestData(configElement)).done(successCallback).fail(failedCallback);
        },
        
        saveLayoutSettings: function (configElement, successCallback, failedCallback) {
            
            this.saveConfig(configElement, successCallback, failedCallback);
            
            for (var index = 0; index < _core.moduleManager.sandboxes.length; index += 1) {
                var sandbox = _core.moduleManager.sandboxes[index];
                
                var configSettings = sandbox.configSettings;
                configSettings.configElement = 'moduleConfig';

                this.saveConfig(configSettings);
            }
        },
        
        logModuleUsage: function (data) {
            var saveSettingsUri = '/api/usage';
            requestService(saveSettingsUri, 'POST', data);
        },
        
        getAllLayouts: function (successCallback, failedCallback) {
            requestService(_configurationServicePath + 'layout', 'POST', getRequestData(null)).done(successCallback).fail(failedCallback);
        },
        
        uploadShared: function (data, successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'registersharedmodule', 'POST', data, false /*contentType*/, false /*processData*/).done(successCallback).fail(failCallback);
        },
        
        getAllShared: function (successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'getsharedmodule').done(successCallback).fail(failCallback);
        },
        
        getShared: function (name, successCallback, failCallback) {
            requestService(_moduleRegistryServicePath + 'getsharedmodule/' + name).done(successCallback).fail(failCallback);
        },

        getRegisteredModules: function (successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'registermodule').done(successCallback).fail(failCallback);
        },
        
        saveModule: function (data, successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'updatemodulemetadata', 'POST', data).done(successCallback).fail(failCallback);
        },
        
        deleteModule: function (data, successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'deleteModuleMetadata', 'DELETE', data).done(successCallback).fail(failCallback);
        },
        
        uploadModule: function (data, successCallback, failCallback) {
            requestService(_moduleRegistryServicePath +'registermodule', 'POST', data, false /*contentType*/, false /*processData*/).done(successCallback).fail(failCallback);
        },
        
        promoteElement: function (data, successCallback, failCallback) {
            requestService('/api/promotelement', 'POST', data).done(successCallback).fail(failCallback);
        },
        
        getDecoders: function (successCallback, failCallback) {
            requestService('/api/stream/decoders').done(successCallback).fail(failCallback);
        },
        
        getEncoders: function (successCallback, failCallback) {
            requestService( '/api/stream/requestgenerators').done(successCallback).fail(failCallback);
        },
    };
});