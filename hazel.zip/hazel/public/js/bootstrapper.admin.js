﻿"use strict";

requirejs.config({
	baseUrl: '../js',
	paths: {
		app: '../js',
		jquery: '../lib/jquery-2.1.3.min',
		libloader: 'plugins/libLoader',
		jqueryui: '../lib/jquery-ui.min',
		cssloader: 'plugins/cssLoader',
		lodash: '../lib/lodash.min',
		lib: '../lib',
		pnotify: '../lib/pnotify.custom.min'
	}

});


require(['require', 'jquery', 'core', 'admin/module', 'admin/shared', 'admin/publish', 'admin/layout', 'admin/promotion', 'admin/common', 
        'admin/dataSources/solace', 'admin/dataSources/csv', 'admin/dataSources/http'],
    function (require, $, core, onModule, onShared, onPublish, onLayout, onPromotion, common, onSolaceDataSource, onCSVDataSource, onHttp) {

	$(function () {

		core.start(workspaceSettings, userInfo);
        buildMenu([
            { text: 'Modules', handler: emptyContentDiv, image: 'icon fa-cubes fa-lg' },
			{ text: 'Registered Modules', handler: onModule, image: 'sublvl icon fa-cube fa-lg' },		
            { text: 'Published Modules', handler: onPublish, image: 'sublvl icon fa-upload fa-lg' },
            
            { text: 'Shared Libraries', handler: onShared, image: 'icon fa-share-alt fa-lg' },
            { text: 'Layouts', handler: onLayout, image: 'icon fa-th-large fa-lg' },

            { text: 'Datasources', handler: emptyContentDiv, image: 'icon fa-database fa-lg' },
            { text: 'HTTP', handler: onHttp, image: 'sublvl icon fa-database fa-lg' },
            { text: 'Solace', handler: onSolaceDataSource, image: 'sublvl icon fa-database fa-lg' },
            { text: 'CSV', handler: onCSVDataSource, image: 'sublvl icon fa-database fa-lg' },

            { text: 'Promotion', handler: onPromotion, image: 'icon fa-external-link' }
		]);
	});

	function buildMenu(arr) {
		var menu = $('#nav-menu');
		var options = '';
		for (var i = 0; i < arr.length; i++) {
		    $('<a href="#"/>').text(arr[i].text).addClass(arr[i].image)
			.appendTo($('<li/>').click(arr[i].handler).click(function () {
                highlight(menu, this);
            })
				.appendTo(menu));
		}
	}

	function highlight(menu, ele) {
	    menu.children().each(function (i, obj) {
	        $(obj).removeClass('active');
	    });
	    $(ele).addClass('active');

	    $('#selectedContent').text($(ele).text());
	}
    
    function emptyContentDiv(){
        $('#contentDiv').html('');
    }
});