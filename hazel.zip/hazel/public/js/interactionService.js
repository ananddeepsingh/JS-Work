﻿"use strict";

define(['require', 'jquery', 'jqueryui', 'pnotify'], function (require, $, jqui, PNotify) {

    function init() {
    }

    function showDialog(element, buttons) {
        element.dialog({
            resizable: false,
            //height: 300,
            //width: 350,
            show: 'fold',
            modal: true,
            overlay: true,
            buttons: buttons
        });
    }

    function showNotice(title, message, type) {
        var notice = new PNotify({
            title: title,
            text: message,
            type: type,
            buttons: {
                closer: false,
                sticker: false
            }
        });
        
        notice.get().click(function () {
            notice.remove();
        })
    }

    function showNotification(title, message) {
        showNotice(title, message, 'info');
    }

    function showError(title, message) {
        showNotice(title, message, 'error');
    }

    return {
        init: init,
        showDialog: showDialog,
        showNotification: showNotification,
        showError: showError
    };
});