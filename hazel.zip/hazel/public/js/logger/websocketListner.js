﻿"use strict";

define(['require', 'lib/socket.io'], function (require, io) {

    var connection = io.connect();

    function ShowLocalDate() {
        var dNow = new Date();
        var localdate = (dNow.getMonth() + 1) + '/' + dNow.getDate() + '/' + dNow.getFullYear() + ' ' + dNow.getHours() + ':' + dNow.getMinutes();
        return localdate;
    }


    function ShowUTCDate() {
        var dNow = new Date();
        var utc = new Date(dNow.getTime() + dNow.getTimezoneOffset() * 60000)
        var utcdate = (utc.getMonth() + 1) + '/' + utc.getDate() + '/' + utc.getFullYear() + ' ' + utc.getHours() + ':' + utc.getMinutes();
        return utcdate;
    }

    return {
        write: function (logObject) {                        
            var logObj = {
                "logObject": logObject,
                "logTime": ShowLocalDate()
            };
            connection.emit('logMessage', logObj);

            console.log('Client Log: from socket > [' + logObject.type + '] ' + logObject.message);

        }
    };
});