﻿"use strict";

define([], function () {
    return {
        write: function (logObject) {
            console.log('[' + logObject.type + '] : Module -->' + logObject.moduleName + ', Message -->' + logObject.message);
        }
    };
});