﻿"use strict";

define(['require'], function (require) {

    var listners = [];

    return {
        addListner: function (listner) {
            listners.push(listner);
        },

        write: function (logObject) {
            for (var i = 0; i < listners.length; i+=1) {
                
                listners[i].write(logObject);
            }
        }


    };
});