﻿"use strict";

define(['require'], function (require) {
    
    var applicationModes = {
        RUN: 'run',
        DESIGN: 'design'
    };
    
    function getModuleConfiguration(moduleName) {
        
        var moduleConfigList = workspaceSettings.moduleConfigList;
        
        var result = $.grep(moduleConfigList, function (e) { return e.PublishedName == moduleName; });
        if (typeof result !== 'undefined' && result.length > 0) {
            return result[0];
        }
        
        return null;
    }
    
    function getModuleName(publishedModuleName) {
        
        var moduleMappingConfigList = workspaceSettings.moduleMappingConfigList;
        
        var result = $.grep(moduleMappingConfigList, function (e) { return e.name == publishedModuleName; });
        if (typeof result !== 'undefined' && result.length > 0) {
            return result[0].value.ModuleName;
        }
        
        return null;
    }
    
    function getModulePath(moduleName, core) {
        
        var moduleMappingConfigList = workspaceSettings.moduleMappingConfigList;

        var result = $.grep(moduleMappingConfigList, function (e) { return e.value.ModuleName == moduleName; });
        if (typeof result !== 'undefined' && result.length > 0) {
            return workspaceSettings.environmentSettings.moduleRegistryPath + result[0].value.path + '.js';
        }
    }
    
    function getLocalDate() {
        var dNow = new Date();
        var localdate = (dNow.getMonth() + 1) + '/' + dNow.getDate() + '/' + dNow.getFullYear() + ' ' + dNow.getHours() + ':' + dNow.getMinutes() + ':' + dNow.getMilliseconds();
        return localdate;
    }
    
    function renderModuleLoadErrorMessage(element)
    {
        element.append('<div><br/><label>Error in loading module. Please contact administrator.</label></div>');
    }
    
    return {
        getModuleConfiguration: getModuleConfiguration,
        getModuleName: getModuleName,
        getModulePath: getModulePath,
        getLocalDate: getLocalDate,
        renderModuleLoadErrorMessage: renderModuleLoadErrorMessage,
        applicationModes: applicationModes
    };
});