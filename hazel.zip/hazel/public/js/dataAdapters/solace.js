﻿"use strict";

require.config({
    paths: {
        solclient: '../lib/solclient'
    },
    shim: {
        solclient: {
            exports: 'solace'
        }
    }
});

define(['require', 'solclient', 'core'], function (require, solace, core) {
    
    return function (config) {
        var session;
        var cacheSession;
        var subscriptionsInWaiting = [];
        var config = config;
        
        this.connect = function (params, success, fail) {
            var self = this;
            var sessionProperties = new solace.SessionProperties();
            sessionProperties.userName = userInfo.userMode === 'impersonate' ? userInfo.impersonatedUserName : userInfo.userName;
            sessionProperties.password = 'HOST=' + userInfo.userIP;
            sessionProperties.vpnName = config.vpn;
            sessionProperties.url = config.url;
            
            // for cache
            var topics = [];
            var subscribe = config.subscribe;
            var liveDataAction = +config.action;
            var cacheSessionProperties = new solace.CacheSessionProperties(config.cacheName, null, null, null);
            
            // create topics
            if (params && params.topics && (params.topics instanceof Array))
                topics = params.topics;
            else
                topics.push(config.topic);
            
            var messageCallback = new solace.MessageRxCBInfo(function (session, message, userObject, RFUObject) {
                var row = {};
                for (var current in message.getSdtContainer().getValue().m_map) {
                    row[current] = message.getSdtContainer().getValue().m_map[current].getValue();
                }
                
                if (success) {
                    try {
                        success(row);
                    } catch (e) {
                        console.error('solace message error ', e);
                        if (fail)
                            fail(session, e.toString(), e);
                    }
                }
            }, null);
            
            var cacheCbInfo = new solace.CacheCBInfo(function (number, cacheRequestResult, userObject) {

            }, null);
            
            
            var eventCallbackInfo = new solace.SessionEventCBInfo(function (session, sessionEvent, userObject, RFUObject) {
                if (sessionEvent.sessionEventCode === solace.SessionEventCode.UP_NOTICE) {
                    console.log('solace session established');
                    
                    for (var i = 0; i < topics.length; ++i) {
                        var topic = new solace.SolclientFactory.createTopic(topics[i]);
                        
                        if (cacheSession)
                            cacheSession.sendCacheRequest(getRequestId(), topic, subscribe, liveDataAction, cacheCbInfo);
                        else
                            self.addSubscription(topics[i]);
                    }
                    
                    // for any subscription inserted before session is created
                    while (subscriptionsInWaiting.length > 0) {
                        self.addSubscription(subscriptionsInWaiting[0]);
                        subscriptionsInWaiting.shift();
                    }

                } else if (sessionEvent.sessionEventCode === solace.SessionEventCode.CONNECTING) {
                    console.log('solace connecting...');
                } else if (sessionEvent.sessionEventCode === solace.SessionEventCode.SUBSCRIPTION_OK) {
                    console.log('solace subscribe/unsubscribe succeed.')
                } else if (sessionEvent.sessionEventCode === solace.SessionEventCode.CAN_ACCEPT_DATA) {
                    while (subscriptionsInWaiting.length > 0) {
                        self.addSubscription(subscriptionsInWaiting[0]);
                        subscriptionsInWaiting.shift();
                    }
                } else {
                    console.error('solace error ' + sessionEvent.toString());
                    if (fail)
                        fail(session, sessionEvent.toString(), sessionEvent);
                }
            });
            
            session = new solace.Session(sessionProperties, messageCallback, eventCallbackInfo);
            
            //build cache if config requested cache snap
            if (config.snapCache)
                cacheSession = session.createCacheSession(cacheSessionProperties);
            
            try {
                session.connect();
            } catch (e) {
                if (fail)
                    fail(e);
                else
                    throw e;
            }
        };
        
        
        this.addSubscription = function (topic_string) {
            var topic = new solace.SolclientFactory.createTopic(topic_string);
            
            if (!session) {
                subscriptionsInWaiting.push(topic_string);
            } else {
                try {
                    session.subscribe(topic, true, topic_string, 3000);
                } catch (e) {
                    if (e instanceof solace.OperationError && e.subcode === solace.ErrorSubcode.INSUFFICIENT_SPACE) {
                        subscriptionsInWaiting.push(topic);
                    } else {
                        throw e;
                    }
                }
            }
        }
        
        this.removeSubscription = function (topic_string_or_array) {
            var array = [];
            
            if (typeof topic_string_or_array === 'string')
                array.push(topic_string_or_array);
            if (topic_string_or_array instanceof Array)
                array = topic_string_or_array;

            if (!session) {
                throw "Session must be established before removing topics."
            } else {
                try {
                    for (var i = 0; i < array.length; ++i) {
                        var topic = new solace.SolclientFactory.createTopic(array[i]);
                        session.unsubscribe(topic, true, array[i], 3000);
                    }
                } catch (e) {
                    throw e;
                }
            }
        }
        
        this.disconnect = function () {
            if (cacheSession)
                cacheSession.dispose();
            session.disconnect();
        }


        function getRequestId() {            
            var arr = new Uint8Array(36);
            window.crypto.getRandomValues(arr);
            var hash = 0;
            for (var i = 0; i < arr.length; ++i) {
                hash = (hash << 5) - hash + arr[i];
                hash = hash & hash;
            }
            return hash;
        }
    };
});