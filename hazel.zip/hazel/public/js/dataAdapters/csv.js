﻿"use strict";

define(['require', 'core'], function (require, _core) {
    return function (config) {
        function requestService(uri, methodType, data, successCallback, failedCallback) {
            return $.ajax({
                type: methodType,
                url: uri,
                dataType: 'json',
                contentType: 'application/json',
                data: data ? JSON.stringify(data) : null,
                async: true,
                success: successCallback,
                error: failedCallback
            });
        }
        
        this.connect = function (params, success, fail) {
            var requestData = {
                dataSourceConfig: config,
                queryParameters: null,
                userDetail: { userMode: _core.userInfo.userMode, impersonatedUserName: _core.userInfo.impersonatedUserName, userName: _core.userInfo.userName }
            };
            requestService('/api/datagateway', 'POST', requestData, success, fail);
        }
    }
});