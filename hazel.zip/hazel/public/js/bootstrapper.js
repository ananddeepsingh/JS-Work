﻿"use strict";

requirejs.config({
    baseUrl: '../js',
    paths: {
        app: '../js',
        jquery: '../lib/jquery-2.1.3.min',
        libloader: 'plugins/libLoader',
        jqueryui: '../lib/jquery-ui.min',
        cssloader: 'plugins/cssLoader',  
        lodash: '../lib/lodash.min',
        lib: '../lib',
        pnotify: '../lib/pnotify.custom.min'
    }
    
});

//global error handler
//requirejs.onError = function (err) {
//    console.error('Error Type:' + err.requireType + ', modules: ' + err.requireModules);
//};

require(['require', 'jquery'], function (require, $) {

    var _modulePath = 'modules/';

    /*!
    * The main entry point. It called when layout loads.
    */
    $(function () {

        require(['core'], function (core) {

            core.start(workspaceSettings, userInfo);
            core.initLayout();
        });

    });

});

