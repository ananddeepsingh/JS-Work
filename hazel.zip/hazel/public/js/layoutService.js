﻿"use strict";

requirejs.config({    
    paths: {
        docker: 'layoutmanager',        
    },
    shim: {
        docker: [
            'layoutmanager/collapser',
            'layoutmanager/drawer',
            'layoutmanager/splitter',
            'layoutmanager/frame',
            'layoutmanager/panel',
            'layoutmanager/layout',
            'layoutmanager/ghost',
            'layoutmanager/tabframe',
            'layoutmanager/iframe']
    }
});

define(['require', 'jquery', 'layoutmanager/docker', 'layoutmanager/iframe', 'interactionService', 'lib/jquery.contextMenu', 'lib/jquery.ui.position'],
    function (require, $, wcDocker, wcIFrame, interactionService) {

    var myDocker;
    var panels = [];
    var _core;
    var _savedLayout;
    var _logger;

    var _popDefaultSize = { h: '400px', w: '400px', x: '111', y: '333' };

    function init(core, registeredModule) {

        _core = core;
        _logger = _core.getService('logger');
        var rootElement = $('div[data-hazel-dock-manager]')[0];

        myDocker = new wcDocker(rootElement, {
            allowDrawers: true,
            responseRate: 10,
            allowContextMenu: false,
            themePath: undefined,
            theme: undefined
        });

        var channel = _core.getService('pageBus').channel('tradeupdate');

        channel.subscribe('save.Layout', function (data) {            
            saveLayout(getURLParameter('layoutName') || prompt('enter layout name'), false);
        });

        channel.subscribe('restore.Layout', function (data) {
            myDocker.restore(_savedLayout);
        });

        if (registeredModule) {
            // register module type
            for (var i = 0; i < registeredModule.length; i++) {
                registerPanelType(registeredModule[i]);
            }
        }        

        registerContextMenu();
    }

    function registerPanelType(module, container)
    {
        myDocker.registerPanelType(module.id,
           {
               faicon: 'comment-o',
               isPersistent: module.isPersistent || false,
               onCreate: function (panel) {                   

                   var $container = $('<div style="position:absolute;top:0px;left:0px;right:0px;bottom:0px;"></div>');
                   panel.layout().addItem($container);

                   var iFrame = new wcIFrame($container, panel);
                   panel.assocContainer = iFrame.createFrame();

                   removePanel(panel._title);
                   panels.push(panel);   

                   panel.addButton('expand', 'fa fa-expand', 'E', 'Expand panel', false);

                   panel.on(wcDocker.EVENT.BUTTON, function (event) {
                       if (event.name === 'expand') {

                           panel._isExpanded = true;
                           var btn = $('<div id="btnPanelRestore" class="fa fa-compress wcFrameButton wcPanelRestoreButton" style="height:20px; width:20px"/>');
                           $('body').append(btn);
                           panel.__trigger(wcDocker.EVENT.EXPANDED, {});

                           btn.click(function (event) {
                               $('#btnPanelRestore').remove();
                               panel._isExpanded = false;
                               panel.__trigger(wcDocker.EVENT.COLLAPSED, {});
                           });
                       }                       
                   });
               }
           });
    }
    
    function createPanel(module) {

        var container = $('<div></div>');
        registerPanelType(module, container);
        myDocker.addPanel(module.id, module.dockstate, getPanel(module.parentPanel), module.option);

        var panel = getPanel(module);        

        return panel;
    }

    function reAdded(module) {
                
        myDocker.addPanel(module.id, module.dockstate, getPanel(module.parentPanel), module.option);
        
    }

    function getPanel(module)
    {
        if (module != null)
        {
            var i;
            for (i = 0; i < panels.length; i += 1) {
                if (module.id === panels[i]._type) {
                    return panels[i];
                }
            }
        }

        return null;
    }

    function removePanel(moduleId)
    {
        var i;
        for (i = 0; i < panels.length; i += 1) {
            if (moduleId === panels[i]._title) {
                panels.slice(i, 1);
            }
        }
    }

    function saveLayout(layoutName, isSaveSettings) {
        var layout = myDocker.save();

        var registeredModules = getRegisteredModules();
        
        var configElement = [{
                name: 'layouts', 
                value: [{
                        name: layoutName, 
                        value: {
                            moduleList: registeredModules,
                            workspace: layout,
                            panelCounter: _core.panelCounter
                        }
                    }]
            }];

        if (typeof isSaveSettings !== 'undefined' && isSaveSettings === true) {
            
            _core.getService('configService').saveLayoutSettings(configElement, function () {
                
                _logger.write({
                    type: 'INFO',
                    message: 'Layout setting saved successfully.',
                    moduleName: 'Layout Service:SaveLayout()'
                });

            }, function () {
                
                _logger.write({
                    type: 'ERROR',
                    message: 'Error in saving layout settings.',
                    moduleName: 'Layout Service:SaveLayout()'
                });

            });
        }
        else {
            _core.getService('configService').saveConfig(configElement, function () {

                _logger.write({
                    type: 'INFO',
                    message: 'Layout saved successfully.',
                    moduleName: 'Layout Service:SaveLayout()'
                });

            }, function () {

                _logger.write({
                    type: 'ERROR',
                    message: 'Error in saving layout.',
                    moduleName: 'Layout Service:SaveLayout()'
                });

            });
        }
    }

    function getRegisteredModules() {
        var registeredModules =[];

        for (var index = 0; index < _core.moduleManager.sandboxes.length; index += 1) {

            registeredModules[index] = _core.moduleManager.sandboxes[index].module;
        }

        return registeredModules;
    }

    function restoreLayout(savedLayout)
    {
        // the saveLayout is empty but parameter 'layoutName' exists. The layout was not found
        
        var layoutName = getURLParameter('layoutName');
        if (typeof savedLayout === 'undefined' || savedLayout === '') {

            var message = 'Welcome to <b>Hazel</b>.\n\nStart by adding panels and saving the layout.\n\nPlease contact administrator for any assistance.';

            if (typeof layoutName !== 'undefined') {
                message = 'Cannot find the requested layout: ' + layoutName;
            }

            interactionService.showNotification('Layout Message', message);
            return;
        }
        
        if (typeof savedLayout === 'object')
            savedLayout = JSON.stringify(savedLayout);
        myDocker.restore(savedLayout);
    }   

    function getURLParameter(name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || undefined
    }

    function saveLayoutDialog(isSaveSettings) {
        var html = '<div><span>Enter layout name:</span><br/>'+
                   '<input type="text" id="txtName" /><div/>';
        html = $(html);
        interactionService.showDialog(html, {
            Ok: function () {

                var name = html.find('#txtName').val();
                saveLayout(name, isSaveSettings);

                $(this).dialog('destroy');                
            },
            Cancel: function () {
                $(this).dialog('destroy');                
            }
        });
    }

    function registerContextMenu() {
        myDocker.menu(
            '.wcFrame',
            function (trigger, event, targetFrame) {
                
                return getContextMenuItems();
                
                function getContextMenuItems() {
                    var items = [];
                    
                    /*NOTE: need clearity on which are ADMIN and USER menu options... */
                    //if (workspaceSettings.applicationMode === _core.helper.applicationModes.DESIGN) {
                        items.push({ name: 'Add Panel', callback: addPanel });
                        items.push({ name: 'Save Layout', callback: saveCurrentLayout });
                        items.push({ name: 'Save Settings', callback: saveCurrentLayoutSettings });
                        items.push({
                            name: 'Properties', callback: showProperties, disabled: function (key, opt) {
                                return targetFrame.panel()._isPlaceholder;
                            }
                        });
                    //}
                    items.push({ name: 'Load Layout', callback: loadAllLayout });                    
                    
                    return items;
                }
                
                function loadAllLayout() {
                    
                    _core.getService('configService').getAllLayouts(function (list) {
                        var option = '';
                        for (var i = 0; i < list.length; i++) {
                            option += '<option value="' + list[i] + '">' + list[i] + '</option>';
                        }
                        
                        var select = $('<select/>').append(option); //'select' refferred in ok closure
                        var div = $('<div title="Load layout"/>').append(select);
                        
                        interactionService.showDialog(div, {
                            Ok: function () {
                                
                                if (_core.userInfo.userMode === 'admin') {
                                    window.location.search = '?userMode=' + _core.userInfo.userMode + '&layoutName=' + select.val();
                                }
                                else if (_core.userInfo.userMode === 'impersonate') {
                                    window.location.search = '?impersonateUser=' + _core.userInfo.impersonatedUserName + '&layoutName=' + select.val();
                                }
                                else {
                                    window.location.search = '?layoutName=' + select.val();
                                }
                                
                                $(this).dialog('destroy');
                            },
                            Cancel: function () {
                                $(this).dialog('destroy');
                            }
                        });
                    }, function () {

                        _logger.write({
                            type: 'ERROR',
                            message: 'Error in get list of all loaded layouts.',
                            moduleName: 'Layout Service:loadAllLayout()'
                        });

                    });
                };
                
                function addPanel() {
                    _core.moduleManager.addModulePanel('single');
                };
                
                function saveCurrentLayout() {
                    // save the name in url parameter or ask for a name
                    var name = getURLParameter('layoutName');
                    if (name) {
                        saveLayout(name, false);
                    } else {
                        saveLayoutDialog(false);
                    }
                };
                
                function saveCurrentLayoutSettings() {
                    // save the name in url parameter or ask for a name
                    var name = getURLParameter('layoutName');
                    if (name) {
                        saveLayout(name, true);
                    } else {
                        saveLayoutDialog(true);
                    }
                };
                
                function showProperties() {
                    var targetSandbox;
                    
                    for (var i = 0; i < _core.moduleManager.sandboxes.length; i++) {

                        if (_core.moduleManager.sandboxes[i].panel === targetFrame.panel()) {
                            targetSandbox = _core.moduleManager.sandboxes[i];
                            break;
                        }
                    }
                    
                    if (targetSandbox && targetSandbox.canRender()) {

                        var div = $('<div title="Edit Properties"/>');
                        targetSandbox.renderEditor(div, targetSandbox.configSettings);
                        
                        interactionService.showDialog(div, {
                            Ok: function () {
                                // save to sandbox config and do not use the return value
                                targetSandbox.getSettings();
                                targetSandbox.applySettings();
                                targetSandbox.saveSettings();
                                $(this).dialog('destroy');
                            },
                            Cancel: function () {
                                $(this).dialog('destroy');
                            }
                        })
                    }
                }

            },
            false /*do not show default options*/);
    }

    return {
        init: init,
        getPanel: getPanel,        
        createPanel: createPanel,
        restoreLayout: restoreLayout,
        reAdded: reAdded
    };
});