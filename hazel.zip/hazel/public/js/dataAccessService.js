﻿"use strict";

define(['require'], function (require) {
    
    var _core;
    var _logger;
    var configService;
    
    function init(core) {
        _core = core;
        _logger = _core.getService('logger');
        configService = _core.getService('configService');
    }

    return {
        init: init,
        getDataSource: function (dataSourceName, callback) {
            var elements = [];
            var appEnv = workspaceSettings.environmentSettings.applicationEnvironment;
            
			elements.push({ configElement: 'dataSourceList', name : [dataSourceName] });
            configService.getConfig(elements, function (data) {
                var type = data[0].value[0].value.type;
                var config = data[0].value[0].value[appEnv];
				if(type === 'csv')
					config = data[0].value[0].value;
				require(['dataAdapters/' + type], function (adapter) {
					if (callback)
						callback(new adapter(config), config);
				});
			});
		}
    };

});