﻿"use strict";

define(['require', 'layoutmanager/docker'], function (require, wcDocker) {

    var _modulePath = 'modules/';
    var _panelConfigElement = null;

    var Sandbox = function (coreObj, module) {

        this.core = coreObj;
        this.module = module;
        this.panel = null;
        this.container = null;

        this.bus.core = coreObj;
        this.logger.core = coreObj;
        this.logger.self = this;

        var path = this.core.helper.getModulePath(this.module.name, this.core);
        
        var moduleInstance = require(path);

        this.moduleObject = new moduleInstance();

        // renderEditor only exists in case of a visual module.
        if (this.canRender()) {
            this.renderEditor = function (div, settings) {
                // clone only properties
                this.configSettings = JSON.parse(JSON.stringify(settings));
                renderPanelProperties(div, settings);
                if (this.moduleObject.renderEditor) {
                    this.moduleObject.renderEditor(div, getModuleSettings(settings));
                }
            }
        }
    };
    

    Sandbox.prototype.getSettings = function () {
        this.configSettings.value = getPanelConfiguration();
        this.configSettings.value.module = typeof this.moduleObject.getSettings === 'function' ? this.moduleObject.getSettings() : undefined;
        return this.configSettings;
    }

    Sandbox.prototype.init = function (module, settings) {

        try {
            //this.module = module;
            this.configSettings = settings;

            this.moduleObject.init(this, getModuleSettings(settings));
        }
        catch (xe) {
            console.log('Error in initilizing module. Detail:' + xe);
            this.core.getService('interactionService').showNotification('Module: ' + module.publishedName + ' failed to initialize.');
        }
    };

    Sandbox.prototype.render = function (panel) {

        try{

            this.panel = panel;

            if (this.panel !== null) {
                this.container = this.panel.assocContainer;
                associatePanelEvents.bind(this, this.panel, this.moduleObject) ();

                setPanelProperties(this.panel, getPanelSettings(this.configSettings));
            }

            if (this.container !== null) {
                this.moduleObject.render(this.container);
            }
        }
        catch(xe)
        {
            this.core.getService('logger')
               .write({
                   type: 'ERROR',
                   message: 'Error in rendering module',
                   moduleName: this.module.name
               });

            console.log('Error in rendering module. Detail:' + xe);

            if (this.container) {
                this.core.helper.renderModuleLoadErrorMessage(this.container);                
            }
        }
    };

    Sandbox.prototype.bus = {

        publish: function (channel, topic, data) {
            this.core.getService('pageBus').publish({
                channel: channel,
                topic: topic,
                data: data
            });
        },

        subscribe: function (channel, topic, callback) {
            return this.core.getService('pageBus').subscribe({
                channel: channel,
                topic: topic,
                callback: callback
            });
        },

        unsubscribe: function (subscription) {
            subscription.unsubscribe();
        }
    };

    Sandbox.prototype.logger = {

        debug: function (message) {
            this.core.getService('logger')
                .write({
                    type: 'DEBUG',
                    message: message,
                    moduleName: this.self.module.name
                });
        },

        info: function (message) {
            this.core.getService('logger')
                           .write({
                               type: 'INFO',
                               message: message,
                               moduleName: this.self.module.name
                           });
        },

        warn: function (message) {
            this.core.getService('logger')
                           .write({
                               type: 'WARN',
                               message: message,
                               moduleName: this.self.module.name
                           });
        },

        error: function (message) {
            this.core.getService('logger')
                           .write({
                               type: 'ERROR',
                               message: message,
                               moduleName: this.self.module.name
                           });
        }

    };

    Sandbox.prototype.loadResource = function () {

        //TBD
    };

    Sandbox.prototype.canRender = function () {

        if (typeof this.moduleObject.render === 'function') {
            return true;
        }

        return false;
    };

    // reapply the configSettings to panel and module
    Sandbox.prototype.applySettings = function(){
        setPanelProperties(this.panel, getPanelSettings(this.configSettings));

        if (this.moduleObject.applySettings) {
            this.moduleObject.applySettings(getModuleSettings(this.configSettings))
        }
    }
    
    Sandbox.prototype.saveSettings = function ()
    {
        if (this.configSettings !== null) {
            
            var configElement = [{
                    name: 'moduleConfig', 
                    value: [this.configSettings]
                }];
            this.core.getService('configService').saveConfig(configElement);
        }
    }

    function associatePanelEvents(panel, module) {
        var self = this;
        panel.on(wcDocker.EVENT.SAVE_LAYOUT, function (data) {
            if (module.onSave) {
                module.onSave(data);
            }
        });

        panel.on(wcDocker.EVENT.RESTORE_LAYOUT, function (data) {
            if (module.onRestore) {
                module.onRestore(data);
            }
        });

        panel.on(wcDocker.EVENT.CLOSED, function () {
            if (module.onClose) {
                module.onClose();
            }
            self.emit('close'); // registered by module manager
        });

        panel.on(wcDocker.EVENT.PERSISTENT_CLOSED, function () {
            if (module.onHide) {
                module.onHide();
            }
        });

        panel.on(wcDocker.EVENT.PERSISTENT_OPENED, function () {
            if (module.onShow) {
                module.onShow();
            }
        });

        panel.on(wcDocker.EVENT.EXPANDED, function () {
            if (module.onExpanded) {
                module.onExpanded();
            }
        });

        panel.on(wcDocker.EVENT.COLLAPSED, function () {
            if (module.onCollapsed) {
                module.onCollapsed();
            }
        });
    }

    function setPanelProperties(panel, settings) {
        if (typeof panel !== 'undefined' || panel !== null) {
            if (settings !== null && typeof settings !== 'undefined') {

                panel.closeable(settings.closeable);
				panel.title(settings.title);
				panel.isTitleHoverEnabled(settings.showTitleBar);
                                
                //handle resizable
                if(panel._parent._parent.$bar) // panel is a child of splitter
                    if (settings.resizeable)
                        panel._parent._parent.$bar.css('border-width', '').css('height', '').css('width',''); // restore default css settings
                    else
                        panel._parent._parent.$bar.css('border-width', '0').css('height', '0').css('width', '0');
                panel.moveable(settings.resizeable);
                panel.docker().__resize(); // force adjust the boundary when resized
            }
        }
    }

    Sandbox.prototype.saveConfig = function (settings) {
        
        if (this.configSettings !== null) {
            
            var configElement = [{
                    name: 'moduleConfig', 
                    value: [this.configSettings]
                }];            
            this.core.getService('configService').saveConfig(configElement);
        }
    };

    function renderPanelProperties(element, settings)
    {
        _panelConfigElement = element;

        element.append(
            '<div id="panelPropertyDiv">' +
                  '<table >' +
                      '<tr>' +
                          '<td width="100px" style="text-align:right;">' +
                                '<span>Resizeable:</span>' +
                          '</td>'+
                          '<td width="200px" style="text-align:left;">' +
                                '<input type="checkbox" id="txtResizeable" checked/><br />' +
                           '</td>' +
                      '</tr>' +

                      '<tr>' +
                          '<td width="100px" style="text-align:right;">' +
                                '<span>Closeable:</span>' +
                         '</td>' +
                         '<td width="200px" style="text-align:left;">' +
                                '<input type="checkbox" id="txtCloseable" checked/><br />' +
                          '</td>' +
                      '</tr>' +

                      '<tr>' +
                          '<td width="100px" style="text-align:right;">' +
                            '<span>ShowTitleBar:</span>' +
                          '</td>' +
                          '<td width="200px" style="text-align:left;">' +
                            ' <input type="checkbox" id="txtShowTitleBar" checked/><br />' +
                          '</td>' +
                      '</tr>' +

                      '<tr>' +
                          '<td width="100px" style="text-align:right;">' +
                            '<span >Title:</span> ' +
                          '</td>' +
                          '<td width="200px" style="text-align:left;">' +
                            '<input type="txt" id="txtTitle" /><br />' +
                          '</td>' +
                      '</tr>' +
                  '</table>' +
            '</div>');

        if (settings) {
            var panel = getPanelSettings(settings);
            if (panel) {
                element.find('#txtResizeable').prop('checked', panel.resizeable);
                element.find('#txtCloseable').prop('checked', panel.closeable);
                element.find('#txtShowTitleBar').prop('checked', panel.showTitleBar);
                element.find('#txtTitle').val(panel.title);
            }
        }
    }

    function getPanelConfiguration()
    {
        var panel = {};
        panel.resizeable = _panelConfigElement.find('#txtResizeable').prop('checked');
        panel.closeable = _panelConfigElement.find('#txtCloseable').prop('checked');
        panel.showTitleBar = _panelConfigElement.find('#txtShowTitleBar').prop('checked');
        panel.title = _panelConfigElement.find('#txtTitle').val();

        return {
            panel: panel
        };
    }

    function getModuleSettings(configSettings) {
        
        return configSettings ? (configSettings.value ? (typeof configSettings.value.module !== 'object' ? (typeof configSettings.value.module !== 'undefined' ? $.parseJSON(configSettings.value.module) : configSettings.value.module) : configSettings.value.module) : undefined) : undefined;
    }
    
    function getPanelSettings(configSettings) {

        return configSettings ? (configSettings.value ? (typeof configSettings.value.panel !== 'object' ? $.parseJSON(configSettings.value.panel) : configSettings.value.panel) : undefined) : undefined;
    }

    function renderErrorMessage(element)
    {
        this.core.helper.renderModuleLoadErrorMessage(element);
    }

    Sandbox.prototype.logUsage = function(eventName, data)
    {
        var moduleUsage = {
            eventName: eventName,
            data: data,
            logTime: this.core.helper.getLocalDate(),
            user: userInfo.userName,
        };
        this.core.getService('configService').logModuleUsage(moduleUsage);
    }

    return Sandbox;
});


