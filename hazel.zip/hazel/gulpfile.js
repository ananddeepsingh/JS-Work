﻿var requirejs = require('requirejs'),
    fs = require('fs'),
    gulp = require('gulp'),
    uglifyCss = require('gulp-uglifycss'),
    concat = require('gulp-concat'),
    htmlreplace = require('gulp-html-replace'),
    settings = require('./package.json');


// require optimizer
gulp.task('scripts', function (cb) {
    requirejs.optimize({
        /*see optimizefunction: http://requirejs.org/docs/node.html */
        mainConfigFile: './public/js/bootstrapper.js', /*https://github.com/jrburke/r.js/blob/master/build/example.build.js*/
        out: './dist/public/js/hazel.min.js',
        name: './bootstrapper',
        findNestedDependencies: true,
        preserveLicenseComments: false,
        
        /* TODO: use regex / onBuildWrite. for build the file without layout dependency
        excludeShallow: [
            'layoutmanager/layout',
            'layoutmanager/panel',
            'layoutmanager/drawer', 
            'layoutmanager/frame',
            'layoutmanager/collapser',
            'layoutmanager/splitter',
            'layoutmanager/ghost',
            'layoutmanager/iframe',
            'layoutmanager/docker',

        ],*/

        onModuleBundleComplete: function (data) {
            console.log(this.out);
            console.log('---------------------------------------');
            for (var i = 0; i < data.included.length; ++i)
                console.log(data.included[i]);
            cb();
        }
    })
});

gulp.task('scripts-admin', function (cb) {
    requirejs.optimize({
        mainConfigFile: './public/js/bootstrapper.admin.js',
        out: './dist/public/js/hazel.admin.min.js',
        name: './bootstrapper.admin',
        findNestedDependencies: true,
        preserveLicenseComments: false,

        onModuleBundleComplete: function (data) {
            console.log(this.out);
            console.log('---------------------------------------');
            for (var i = 0; i < data.included.length; ++i)
                console.log(data.included[i]);
            cb();
        }
    })
});



// css minifier
gulp.task('cssmin', function () {
    return gulp.src([
        './public/assets/font-awesome.css',
        './public/assets/layoutmanager.css', 
        './public/assets/hazel.css', 
        './public/assets/jquery-ui.min.css',
        './public/assets/jquery-ui.theme.min.css',
        './public/assets/jquery.contextMenu.css',
        './public/assets/pnotify.custom.min.css'])
        .pipe(uglifyCss())
        .pipe(concat('style.min.css'))
        .pipe(gulp.dest('./dist/public/assets'));
});

gulp.task('cssmin-admin', function () {
    return gulp.src([
        './public/assets/font-awesome.css',
        './public/assets/pnotify.custom.min.css',
        './public/assets/admin.css', 
        './public/assets/bootstrap.min.css'])
        .pipe(uglifyCss())
        .pipe(concat('style.admin.min.css'))
        .pipe(gulp.dest('./dist/public/assets'));
});

// copy plugins. NOTE: default plugins are NOT inlined in the single file
gulp.task('copy-plugins', function () {
    return gulp.src('./public/js/plugins/*.*')
        .pipe(gulp.dest('./dist/public/js/plugins'));
});

// copy plugins. NOTE: default plugins are NOT inlined in the single file
gulp.task('copy-dataAdapters', function () {
    return gulp.src('./public/js/dataAdapters/*.*')
        .pipe(gulp.dest('./dist/public/js/dataAdapters'));
});

// copy images
gulp.task('copy-img', function () {
    return gulp.src([
        './public/assets/images/*.*'
    ])
        .pipe(gulp.dest('./dist/public/assets/images'));
});

// copy fonts
gulp.task('copy-font', function () {
    return gulp.src('./public/assets/fonts/*.*')
        .pipe(gulp.dest('./dist/public/assets/fonts'));
});

// copy icon file
gulp.task('copy-icon', function () {
    return gulp.src('./public/favicon.ico')
        .pipe(gulp.dest('./dist/public'));
});

// copy lib js
gulp.task('copy-lib-js', function () {
    return gulp.src([
        './public/lib/require.js'
        ])
        .pipe(gulp.dest('./dist/public/js'));
});

// copy server files
gulp.task('copy-server', function () {
    return gulp.src([ /*select all server files individually*/
        './app.js',
        './cluster.js',
        './utility.js',
        './package.json',
        './controller/**/*'
    ], { base: './' })/*required to preserve folder structure*/
        .pipe(gulp.dest('dist'));
});

// copy all
// TODO: use merge-stream to avoiding naming the tasks
gulp.task('copy-files', [
    'copy-plugins',
    'copy-dataAdapters',
    'copy-img',
    'copy-font',
    'copy-icon',
    'copy-lib-js',
    'copy-server'
]);

// write installer and runner 
// task depends on copy as 'dist' folder should be present.
gulp.task('write-batch', ['copy-files'], function (cb) {
    // installer file contents
    var installer = 'npm install --production';
    
    // runner file contents
    var mainFileName = settings.main;
    var runner = 'node ' + mainFileName;
    
    fs.writeFile('dist/installer.bat', installer, function (err) {
        if (!err) {
            fs.writeFile('dist/runner.bat', runner, cb);
        } else {
            throw err;
        }
    });
    
});

//process view files - fix paths
gulp.task('process-view', function () {
    /*https://www.npmjs.com/package/gulp-html-replace */

    // NOTE: repeating html-replace function as workaround of bug: https://github.com/VFK/gulp-html-replace/issues/39
    gulp.src([
        './views/index.ejs'
        ])
        .pipe(htmlreplace({
        css: '/assets/style.min.css',
        js: {
            src: [['/js/hazel.min.js', '/js/require.js']],
            tpl: '<script data-main="%s" src="%s"></script>'
        }
    }))
        .pipe(gulp.dest('./dist/views'));

    gulp.src([
        './views/admin.ejs'
    ])
        .pipe(htmlreplace({
        css: 'assets/style.admin.min.css',
        js: {
            src: [['/js/hazel.admin.min.js', '/js/require.js']],
            tpl: '<script data-main="%s" src="%s"></script>'
        }
    }))
        .pipe(gulp.dest('./dist/views'));
});


// default task
gulp.task('default', [
    'scripts',
    'scripts-admin',
    'cssmin',
    'cssmin-admin',
    'write-batch',
    'process-view'
]);