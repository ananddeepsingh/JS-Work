﻿"use strict";

var express = require('express');
var app = express();
var path = require('path');

var http = require('http').createServer(app);
var cors = require('cors');

// initilize object to setup the global settings
global.packageData = {};

var nodeSettings = require('./nodeSettings.json');
var applicationEnvironment = nodeSettings.applicationEnvironment; // get env of the appEnv
//get node settings
for (var current in nodeSettings.settings[applicationEnvironment]) {
    
    global.packageData[current] = nodeSettings.settings[applicationEnvironment][current];
}

//get application settings
var applicationSettings = require('./applicationSettings.json');
for (var current in applicationSettings.settings[applicationEnvironment]) {
    
    global.packageData[current] = applicationSettings.settings[applicationEnvironment][current];
}

app.use(cors());

 //install body-parser
var bodyParser = require('body-parser');
app.use(bodyParser.json({limit: '1000mb'})); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// initialize controllers
app.use('/api/moduleregistry', require('./controller/module'));

app.use(express.static('data'));

// start the server
http.listen(global.packageData.httpPort, function (err) {
    
    if (!err) {
        console.log("Server is started on port " + global.packageData.httpPort);
    }
    else {
        console.log("Server failed to start. Error[" + err + "].");
    }
    
});
