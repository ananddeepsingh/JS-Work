﻿"use strict";

var syncRequest = require('sync-request');

exports.sort_by = function (field, reverse) {
    
    var key = function (x) { return x[field] };
    
    reverse = !reverse ? 1 : -1;
    
    return function (a, b) {
        
        return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
    }
}

exports.getConfig = function (elements) {
    var res = syncRequest('POST', global.packageData.configurationServiceUrl + 'getConfig', {
        json: { data: elements }
    });
    return JSON.parse(res.getBody('utf8'));
}

exports.saveConfig = function (configElement) {
    var res = syncRequest('POST', global.packageData.configurationServiceUrl + 'saveConfig', {
        json: { data: configElement }
    });
    return JSON.parse(res.getBody('utf8'));
}

exports.deleteConfig = function (configElement) {    
    var res = syncRequest('DELETE', global.packageData.configurationServiceUrl + 'deleteConfigQuery?configElement=' + configElement.configElement + '&name=' + configElement.name, null);
    return JSON.parse(res.getBody('utf8'));
}