﻿"use strict";

var router = require('express').Router();

var multer = require('multer');
var uploadShared = multer({ dest: global.packageData.sharedDirPath });
var util = require('../utility');
var fs = require('fs-extra');

router.post('/', uploadShared.single('file'), updateSharedResource);
router.get('/:name', getSharedResource);
router.get('/', getSharedResource);


function getSharedResource(req, res, next){
    
    var name = req.params.name || '';
    var elements = util.getConfig("sharedConfig", name);

    res.json(elements);
    res.end();
}

function updateSharedResource(req, res, next) {
    
    if (!req.file) {
        res.status(500).json({ message: 'shared file missing' });
        return;
    }

    deleteIfExists(req.body.filename);
    
    var configElement = {
        configElement: 'sharedConfig',
        name: req.body.name,
        value: {
            filename: '/shared/' + req.file.filename,
            version: req.body.version,
            keyword: req.body.keyword
        }
    };
    
    util.saveConfig(configElement);
    
    res.json({ message: "File is updated successfully." });
}

function deleteIfExists(fileName, config) {
    if (fileName != '') {        
        // delete file
        var file = fileName.substring('/shared/'.length);
        fs.removeSync(global.packageData.sharedDirPath + '/' + file);
    }
}

module.exports = router;