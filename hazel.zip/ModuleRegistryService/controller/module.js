﻿"use strict";

var router = require('express').Router();

var moduleDir = global.packageData.moduleRegistryDirPath;
var multer = require('multer');
var uploadModule = multer({ dest: moduleDir });
var uploadShared = multer({ dest: global.packageData.sharedDirPath });
var fs = require('fs-extra');
var fStream = require('fstream');
var unzip = require('unzip');
var util = require('../utility');

var AdmZip = require('adm-zip');
var toBuffer = require('typedarray-to-buffer');
var archiver = require('archiver');

router.post('/registermodule', uploadModule.single('fileToUpload'), registerModule);
router.get('/registermodule', getAllRegisteredModules);
router.post('/updatemodulemetadata', updateModuleMetadata);
router.delete('/deleteModuleMetadata', deleteModuleMetadata);

router.post('/registersharedmodule', uploadShared.single('file'), updateSharedResource);
router.get('/getsharedmodule/:name', getSharedResource);
router.get('/getsharedmodule', getSharedResource);

router.post('/getModulePackage', getModulePackage);
router.post('/promoteModulePackage', promoteModulePackage);

router.post('/getSharedResourcePackage', getSharedResourcePackage);
router.post('/promoteSharedResourcePackage', promoteSharedResourcePackage);

function registerModule(req, res, next) {
    
    var module = JSON.parse(req.body["packageData"]);
    var moduleName = module.name;
    console.log("Module name :- " + moduleName);
    var modulePath = moduleDir + '/' + moduleName;
    
    var writePackageJson = function (path, obj) {
        fs.writeFileSync(path + '/package.json', JSON.stringify(obj, null, 4), 'utf8');
    };
    
    // empty dir if file is recieved
    var func = req.file ? fs.emptyDir : fs.ensureDir;
    func(modulePath, function (err) {
        if (err) {
            console.log("Error occurred while creating folder. :-  " + err);
            res.json({ message: "Error occurred while creating folder." });
        } else {            
            if (req.file) {
                var readStream = fs.createReadStream(req.file.path);
                var writeStream = fStream.Writer(modulePath);
                
                readStream
                .pipe(unzip.Parse())
                .pipe(writeStream)
                .on('close', function (close) {
                    console.log("unzip completed.");
                    //delete zip file
                    fs.unlinkSync(req.file.path);
                    
                    // write package.json
                    writePackageJson(modulePath, module);
                    
                    res.json({ message: "upload successful" });
                })
                .on('err', function (close) {
                    console.log("error");
                    //delete zip file
                    fs.unlinkSync(req.file.path);
                    
                    res.json({ message: "upload failed" });
                });
            } else {
                // write package.json even wen file is not being uploaded
                writePackageJson(modulePath, module);
                res.json({ message: "config package updated" });
            }
                                
        }
    });
}

function getAllRegisteredModules(req, res, next){

    var data = [];

    // read all folders of the /data/modules
    var folders = fs.readdirSync(moduleDir);

    // read name from package.json
    for (var i = 0; i < folders.length; ++i) {
        try {
            var packageData = JSON.parse(
                fs.readFileSync(moduleDir + '/' + folders[i] + '/package.json', 'utf8'));
            
            packageData.path = packageData.name + '/' + packageData.main;
            data.push(packageData);
        } catch (ex) {
            // package.json was not found
        }
    }
    
    data.sort(util.sort_by('name', false));    

    res.json(data);
}

function updateModuleMetadata(req, res, next){
    
    util.saveConfig(req.body.data);    

    res.json({data: 'success'});
}

function moduleConfigExists(settings, module) {
    
    var element = util.getConfig("moduleConfig", module.name);
    if (element)
        return true;

    return false;
}

function deleteModuleMetadata(req, res, next) {
        
    try {
        
        var publishedName = req.body.name;
        util.deleteConfig({ configElement: "moduleConfig", name: publishedName });
        util.deleteConfig({ configElement: "moduleMappingConfigList", name: publishedName });
        res.json({ message: 'sucessfully deleted' });
    } catch (ex) {
        res.status(500);
        res.json({ message: 'not sucessful ' + ex });
    }    
}

function getSharedResource(req, res, next) {
    
    var name = req.params.name || '';
    
    var elements = [];
    elements.push({ configElement: 'sharedConfig', name : (name !== '' ? [name] : []) });

    var value = util.getConfig(elements);
    
    res.json(value);
    res.end();
}

function updateSharedResource(req, res, next) {
    
    if (!req.file) {
        res.status(500).json({ message: 'shared file missing' });
        return;
    }
    
    deleteIfExists(req.body.filename);
    
    var configElement = [{
            name: 'sharedConfig',
            value: [{
                    name: req.body.name,
                    value: {
                        filename: '/shared/' + req.file.filename,
                        version: req.body.version,
                        keyword: req.body.keyword
                    }
                }]
        }];
    
    util.saveConfig(configElement);
    
    res.json({ message: "File is updated successfully." });
}

function deleteIfExists(fileName, config) {
    if (fileName != '') {
        // delete file
        var file = fileName.substring('/shared/'.length);
        fs.removeSync(global.packageData.sharedDirPath + '/' + file);
    }
}

function getModulePackage(req, res, next) {
    
    try {
        var element = req.body.data;
        
        var archive = archiver('zip');
        archive.on('error', function (err) {
            throw err;
        });
        
        archive.pipe(res);
        
        var moduleName = element.value.ModuleName;
        
        var moduleDirectory = moduleDir + "/" + moduleName;
        
        archive.directory(moduleDirectory, moduleName);
        
        archive.finalize();
    }
    catch (xe) {
        console.log('GetModulePackage-->Error: ' + xe.message);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

function promoteModulePackage(req, res, next) {
    
    try {
        var element = req.body.data;
        
        if (element.modulePackage !== null) {
            
            var responseBuffer = toBuffer(element.modulePackage.data);
            
            var moduleDirectory = moduleDir + "/temp";
            
            var zip = new AdmZip(responseBuffer);
            zip.extractAllTo(moduleDir, /*overwrite*/true);
        }
        
        util.saveConfig(element.config);
        
        res.json({ status: 'ok' });
    
    }
    catch (xe) {
        console.log('PromoteModulePackage-->Error: ' + xe.message);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

function getSharedResourcePackage(req, res, next)
{
    try {
        var element = req.body.data;
        
        var archive = archiver('zip');
        archive.on('error', function (err) {
            throw err;
        });
        
        archive.pipe(res);
        
        var file = element.value.filename.substring('/shared/'.length);
        
        var sharedModuleDirectory = global.packageData.sharedDirPath + "/" + file;
        
        archive.file(sharedModuleDirectory, { name: file });
        
        archive.finalize();    
    }
    catch (xe) {
        console.log('GetSharedResourcePackage-->Error: ' + xe.message);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

function promoteSharedResourcePackage(req, res, next)
{
    try {
        var element = req.body.data;
        
        if (element.modulePackage !== null) {
            
            var responseBuffer = toBuffer(element.modulePackage.data);
            
            var sharedModuleDirectory = global.packageData.sharedDirPath + "/temp";
            
            var zip = new AdmZip(responseBuffer);
            zip.extractAllTo(global.packageData.sharedDirPath, /*overwrite*/true);
        }
        
        util.saveConfig(element.config);
        
        res.json({status:'ok'});
    }
    catch (xe) {
        console.log('PromoteSharedResourcePackage-->Error: ' + xe.message);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

module.exports = router;