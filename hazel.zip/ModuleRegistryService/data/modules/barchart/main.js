﻿"use strict";

define(['require', './scripts/d3.min.js', 
    "cssloader!./Content/d3.chart.css"], function (require, d3) {
    
    var moduleInstance = function () {
        
        var _context, _element, _eventSource, _configElement;
        
        var _settings = {};
        
        
        function init(context, settings) {
            
            _context = context;            
            _settings = settings;        
        }
        
        function render(element) {
            
            _element = $(element);
            _element.append('<div id="barchart"></div>'+
                            '<div id="tooltip" class="hidden">' +
                            '<p> Market Share: <span id="marketshare">100</span>%</p>'+
                            '<p>Notional Amount: $<span id="notionalamount">100</span></p></div>');
            
            var config = {
                
                line: ['marketshare', 'noofissues'],
                barspace: ".4",
                tickpadding: "5",
                ticks: "5",
                circleRadius: "4",
                //legend: { translatecoord1: "400", translatecoord2: "80" , position: "110", rectY: "65", textWidth: "10", rectHeight: "10", textY: "73", textHeight: "30", textWidth: "400", textColor: "black" },

            };
            
            _context.core.getService('dataAccessService').getDataSource(_settings.dataSource, function (adapter, config) {
                
                adapter.connect(config, function (data) {
                    
                    
                    var legendData = [{ name: "Market Share in %", color: "#8A3837" }, { name: "Notional Amount in $(Others)", color: "#84914D" }];
                    
                    var margin = { top: 20, right: 50, bottom: 30, left: 50 },
                        width = 800 - margin.left - margin.right,
                        height = 400 - margin.top - margin.bottom;
                    
                    
                    var x = d3.scale.ordinal().rangeRoundBands([0, width], .4);
                    var y = d3.scale.linear().range([height, 0]);
                    
                    // Create objects for x-axis,y-axis(left),y-axis(right)
                    var xAxis = d3.svg.axis().scale(x).orient("bottom");
                    var yAxis = d3.svg.axis().scale(y).orient("left").innerTickSize(-width).tickPadding(5).ticks(5);
                    var yAxisRight = d3.svg.axis().scale(y).orient("right").outerTickSize(0).ticks(5);
                    
                    // Append svg object
                    var svg = d3.select("#barchart").append("svg")
                   .attr("width", width + margin.left + margin.right)
                   .attr("height", height + margin.top + margin.bottom)
                   .append("g")
                   .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
                    
                    data.forEach(function (d) {
                        d.Notionalamount = +d.Notionalamount;
                    });
                    
                    
                    x.domain(data.map(function (d) { return d.DealerName; }));
                    y.domain([0, d3.max(data, function (d) { return d.Notionalamount; })]);
                    
                    // Add x-axis,y-axis on left and y-axis on right
                    svg.append("g").attr("class", "x axis")
                        .attr("transform", "translate(0," + height + ")")
                        .call(xAxis);
                    
                    svg.append("g")
                        .attr("class", "y axis")
                        .call(yAxis);
                    
                    svg.append("g")
                        .attr("class", "y axis")
                        .attr("transform", "translate(" + width + " ,0)")
                        .call(yAxisRight);
                    
                    // Add Bar with Tooltip
                    svg.selectAll(".bar")
                        .data(data)
                        .enter().append("rect")
                        .attr("class", "bar")
                        .attr("x", function (d) { return x(d.DealerName); })
                        .attr("width", x.rangeBand())
                        .attr("y", function (d) { return y(d.Notionalamount); })
                        .attr("height", function (d) { return height - y(d.Notionalamount); })
                        .on("mouseover", function (d) {
                                d3.select("#tooltip")
                                    .style("left", d3.event.pageX + "px")
                                    .style("top", d3.event.pageY + "px")
                                    .style("opacity", 1)
                                    .select("#marketshare")
                                    .text(d.marketshare);
                        
                                d3.select("#tooltip")
                                    .style("left", d3.event.pageX + "px")
                                    .style("top", d3.event.pageY + "px")
                                    .style("opacity", 1)
                                    .select("#notionalamount")
                                    .text(d.Notionalamount);
              
                        }).on("mouseout", function () {
                                d3.select("#tooltip")
                                    .style("opacity", 0);;
                    });
                    
                    
                    // Add Line 
                    var valueline = d3.svg.line().x(function (d) {
                        return x(d.DealerName) + 15;
                    })
                                       .y(function (d) {
                        return y(d.marketshare);
                    });
                    
                    svg.append("path").attr("d", valueline(data)).attr("class", "line");
                    
                    // Add Circle for line
                    svg.selectAll("dot")
                      .data(data)
                      .enter().append("circle")
                      .attr("r", 4)
                      .attr("cx", function (d) { return x(d.DealerName) + 15 })
                      .attr("cy", function (d) { return y(d.marketshare); });
                    
                            // Add Legend   
                            var legend = svg.append("g")
                        .attr("class", "legend")
                        .attr("transform", "translate(" + (width - 400) + ", -80)");
                    
                        legend.selectAll('g').data(legendData)
                        .enter()
                        .append('g')
                        .each(function (d, i) {
                                    var g = d3.select(this);
                                    g.append("rect")
                              .attr("x", i * 110)//  110:this value is configurable
                              .attr("y", 65)
                              .attr("width", 10)
                              .attr("height", 10)
                              .style("fill", function (d) { return d.color });
                        
                                    g.append("text")
                               .attr("x", i * 110 + 15)//  110:this value is configurable
                               .attr("y", 73)
                               .attr("height", 30)
                               .attr("width", 400)
                               .style("fill", "black")
                               .text(function (d) { return d.name });
                                });

                            }, function (err) { 
								console.error(err); 
							});

                    });
        }
        
        function onClose() {
            _context.logUsage('Module Closed', { Status: 'done' });
        }
        
        // fucntion for editor
        
        function renderEditor(element, defaults /*from published metadata*/) {
            _configElement = element;
            
            if (!defaults) {
                _settings.dataSource = '';
            } else {
                
                _settings = defaults;
                _settings.dataSource = defaults.dataSource || _settings.dataSource;
            }
            
            
            element.append(
                '<div id="dialog-confirm"">' +
                      '<span>DataSource:</span> <input type="text" id="txtDataSource" value="' + _settings.dataSource + '"/>' +
                '</div>');
        }
        
        function getSettings() {
            _settings.dataSource = _configElement.find('#txtDataSource').val();
            return {
                dataSource: _settings.dataSource
            };
        }
        
        return {
            init: init,
            render: render,
            onClose: onClose,
            renderEditor: renderEditor,
            getSettings: getSettings
        };
    }
    
    return moduleInstance;
});