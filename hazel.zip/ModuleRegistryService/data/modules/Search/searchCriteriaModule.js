﻿"use strict";


define(['require', "cssloader!./css/style.css"], function (require) {

    var moduleInstance = function () {

    var _context, _element, _eventSource, _settings;

    function init(context, settings) {
        
        _context = context;

        _settings = settings;
        
    }

    function render(element) {

        _element = $(element);

        _element.html(
             
        '<br>'+
        '<span style="float: left;">' +
            //'&nbsp;Trade Id:' +
            //'<input type="number" id="orderIdValue" />&nbsp;' +

            '<label style="width:150px; text-align:right;">&nbsp;Client:</label>' +
            '<select id="securityOptions">' +
                  '<option style="display:none;" value="default">--Select Client--</option>' +
            '</select> &nbsp;' +
            '<input type="button" id="searchButton" value="Search" />&nbsp;' +
            '<input type="button" id="refreshButton" value="Refresh" />' +
        '</span>' +
        '<span style="float: right;">' +
                       
        '</span>');

        _element.find('#searchButton').click(function (event) {

            //var orderIdValue = $('#orderIdValue').val();
            //var amountValue = $('#amountValue').val();

            //_context.bus.publish('tradeupdate', 'search.position', { data: orderIdValue });

            var securitySelect = document.getElementById("securityOptions");
            if (typeof securitySelect !== 'undefined') {
                var securityDescription = securitySelect.options[securitySelect.selectedIndex].text;
                var cusip = securitySelect.options[securitySelect.selectedIndex].value;
                
                if (cusip !== 'default') {

                    _context.bus.publish('tradeupdate', 'search.cusip', { securitydescription: securityDescription, cusip: cusip });
                }
            }
            
        });

        _element.find('#refreshButton').click(function (event) {            
            _context.bus.publish('tradeupdate', 'refresh.position', { data: 'refresh' });
        });

        _element.find('#saveLayoutButton').click(function (event) {
            _context.bus.publish('tradeupdate', 'save.Layout', { data: 'save' });
        });

        _element.find('#restoreLayoutButton').click(function (event) {
            _context.bus.publish('tradeupdate', 'restore.Layout', {data: 'restore'});            
        });

        _element.find('#openTicketButton').click(function (event) {            
            _context.saveConfig(_settings);
        });

        _element.find('#openModule').click(function (event) {

            var e = document.getElementById("moduleOptions");
            var moduleName = e.options[e.selectedIndex].value;

            if (moduleName === 'openSingleModule') {
                _context.core.moduleManager.addModulePanel('single');
                return;
            }

            if (moduleName !== 'default') {

                var moduleTitle = e.options[e.selectedIndex].text;

                //_context.core.moduleManager.createModule({ name: moduleName, title: moduleTitle, isHidden: false, dockstate: 'float', option: { h: '140px', w: '500px', x: '330', y: '333' } });
                _context.bus.publish('modulehandler', 'open.module', { data: { name: moduleName, title: moduleTitle, isHidden: false, dockstate: 'float', option: { h: '140px', w: '500px', x: '330', y: '333' } } });
            }
            else
            {
                alert('Please select valid module.');
            }

        });

        addSecurityData();
    }

    function addSecurityData() {

	var data = [
	{Cusip : '1832 ASSET MANAGEMENT L.P GOF', SecurityDescription : '1832 ASSET MANAGEMENT L.P GOF'},
	{Cusip : 'ABERDN', SecurityDescription : 'ABERDN'},
	{Cusip : 'ABN AMRO BANK (LUXEMBOURG) SA', SecurityDescription : 'ABN AMRO BANK (LUXEMBOURG) SA'},
	{Cusip : 'BARCLAYS BANK SUISSE SA', SecurityDescription : 'BARCLAYS BANK SUISSE SA'},
	{Cusip : 'BARING ASSET MGMT LIMITED-LONDON', SecurityDescription : 'BARING ASSET MGMT LIMITED-LONDON'},
	{Cusip : 'BLACKROCK FINANCIAL MGMT-WILMINGTON', SecurityDescription : 'BLACKROCK FINANCIAL MGMT-WILMINGTON'},
	{Cusip : 'BMO ASSET MANAGEMENT CORP', SecurityDescription : 'BMO ASSET MANAGEMENT CORP'},
	{Cusip : 'BONDPARTNERS SA', SecurityDescription : 'BONDPARTNERS SA'},
	{Cusip : 'BREAN MURRAY, CARRET & CO, NY', SecurityDescription : 'BREAN MURRAY, CARRET & CO, NY'},
	{Cusip : 'CALIBER HOME LOANS, INC.', SecurityDescription : 'CALIBER HOME LOANS, INC.'},
	{Cusip : 'CAPITAL RESEARCH AND MGMT CO', SecurityDescription : 'CAPITAL RESEARCH AND MGMT CO'},
	{Cusip : 'CITADEL-CITDL GLBL FD INC MASTER FD', SecurityDescription : 'CITADEL-CITDL GLBL FD INC MASTER FD'},
	{Cusip : 'CITIBANK NA-LONDON', SecurityDescription : 'CITIBANK NA-LONDON'},
	{Cusip : 'COLONIAL FIRST STATE INV LTD', SecurityDescription : 'COLONIAL FIRST STATE INV LTD'},
	{Cusip : 'COLUMBIA MGMT INV ADVISERS LLC', SecurityDescription : 'COLUMBIA MGMT INV ADVISERS LLC'},
	{Cusip : 'FEDERAL RESERVE BK- NEW YORK', SecurityDescription : 'FEDERAL RESERVE BK- NEW YORK'},
	{Cusip : 'LOOP CAPITAL MARKETS LLC', SecurityDescription : 'LOOP CAPITAL MARKETS LLC'},
	{Cusip : 'GAM INV MNGT SWITZ LTD', SecurityDescription : 'GAM INV MNGT SWITZ LTD'},
	
	]
            //clear the option list
            var selectElement = document.getElementById('securityOptions');
            if (typeof selectElement !== 'undefined' && selectElement !== null) {
                selectElement.options.length = 0;
            }

            var securitySelect = $('#securityOptions');

            if (typeof securitySelect != 'undefined' && securitySelect !== null) {
                //add default option item
                securitySelect.append($('<option/>').attr("value", 'default').text('--Select Client--'));

                for (var i = 0; i < data.length; i++) {
                    securitySelect.append($("<option/>").attr("value", data[i].Cusip).text(data[i].SecurityDescription));
                }
            }

    }

    return {
        init: init,
        render: render
    };

    }

    return moduleInstance;
});