﻿"use strict";

//requirejs.config({

//    paths: {
//        kendo: require.toUrl('./')+'./lib/kendo.all.min'
//    },
//    shim: {
//        'kendo': ['jquery']
//    }
//});

//define(['require', 'kendo', 'libloader!MessageBox'], function (require, kenod, lib1) {

define(['require', './lib/kendo.all.min.js', "cssloader!./css/kendo/kendo.common.min.css",
    "cssloader!./css/kendo/kendo.default.min.css",
    "cssloader!./css/kendo/kendo.dataviz.min.css",
    "cssloader!./css/kendo/kendo.dataviz.default.min.css",
    "cssloader!./css/kendo/style.css"], function (require, kendo, messageBox) {

        var moduleInstance = function () {

            var _context, _element, _eventSource;

            function init(context, settings) {

                _context = context;

                if (!!window.EventSource) {
                    _eventSource = new EventSource('/Hazel.MockData.Api/api/positionupdates');

                    _eventSource.addEventListener('open', function (event) {
                        _context.logger.info('Web api connection open.');
                    }, false);

                    _eventSource.addEventListener('error', function (event) {
                        if (event.readyState === EventSource.CLOSED) {
                            _context.logger.info('Web api connection closed.');
                        }
                    }, false);
                }
				
                _eventSource.addEventListener('message', function (event) {
                    var data = $.parseJSON(event.data);

                }, false);

                _context.bus.subscribe('tradeupdate', 'search.position', function (data) {

                    // Our filter, an empty array mean "no filter"
                    var filter = [];

                    // Get the DataSource
                    var dataSource = $(_element).data('kendoGrid').dataSource;

                    var orderIDValue = Number(data.data);

                    if (orderIDValue) {
                        filter.push(
                                { field: 'OrderID', operator: 'eq', value: orderIDValue }
                        );
                    }

                    // Apply the filter.
                    dataSource.filter(filter);
                });

                _context.bus.subscribe('tradeupdate', 'search.cusip', function (data) {

                    // Our filter, an empty array mean "no filter"
                    var filter = [];

                    // Get the DataSource
                    var dataSource = $(_element).data('kendoGrid').dataSource;

                    if (data.cusip) {
                        filter.push(
                                { field: 'SecurityDescription', operator: 'eq', value: data.cusip }
                        );
                    }

                    // Apply the filter.
                    dataSource.filter(filter);
                });


                _context.bus.subscribe('tradeupdate', 'refresh.position', function (data) {
                    // Get the DataSource
                    var dataSource = $(_element).data('kendoGrid').dataSource;

                    // Apply the filter.
                    dataSource.filter({});
                });

            }

            function render(element) {

                _element = element;

                //testTemplating();

                $(_element).kendoGrid({

                    dataSource: {
                        //pageSize: 30,
                        type: "jsonp",
                        transport: {

                            read: "http://localhost:5000/modules/csv_data/rfqdata.json",
                            push: function (dataSource) {
								
								
								window.setInterval(function(){
									var r = Math.ceil(Math.random() * 20);
									
									applyUpDownColorRule({ OrderID: r, Amount: Math.round(Math.random()*1000000) }, dataSource);
									
								}, 2000);
				
								/*
                                _eventSource.addEventListener('message', function (event) {

                                    var data = $.parseJSON(event.data);
                                    applyUpDownColorRule(data, dataSource);

                                }, false);*/
                            }

                        },
                        schema: {
                            model: {
                                id: "OrderId",

                                fields: {
                                    EnteredOn: { type: 'date' },
                                    RBCState: { type: 'date' },
                                    OrderId: { type: 'number' },
                                    Currency: { type: "string" },
                                    SecurityDescription: { type: "string" },
                                    Amount: { type: "number" },
                                    DisplayPrice: { type: "number" },
                                    QuoteYield: { type: "string" },
                                    Counterparty: { type: "string" },
                                    TradeDate: { type: 'date' },
                                    SettleDate: { type: 'date' }
                                }
                            }
                        },

                        serverPaging: false,
                        serverFiltering: false,
                        serverSorting: false
                    },
                    scrollable: {
                        virtual: true
                    },
                    filterable: true,
                    sortable: true,
                    resizable: true,
                    selectable: "single",
                    //pageable: {
                    //    info: true,
                    //    numeric: false,
                    //    previousNext: false
                    //},
                    columns: [
                            { field: "OrderId", filterable: false, width: 60, title: "Trade Id" },
                            { field: "EnteredOn", title: "Entered On", width: 84, filterable: false, format: "{0:yyyy-MM-dd}" },
                            { field: "UpdatedOn", title: "Updated On", width: 84, filterable: false, format: "{0:yyyy-MM-dd}" },
                            { field: "SecurityDescription", title: "Sec Description", width: 170, filterable: false },
                            {
                                field: "Amount", title: "Amount", width: 80, filterable: false,
                                attributes: {
                                    "class": "table-cell",
                                    style: "text-align: right"
                                }
                            },
                            {
                                field: "Notional", title: "Notional", width: 80, filterable: false,
                                attributes: {
                                    "class": "table-cell",
                                    style: "text-align: right"
                                }
                            },
                            { field: "OrigSystemStatus", title: "Orig System Status", width: 100, filterable: false },
                            { field: "Cusip", title: "Cusip", width: 100, filterable: false },
                            { field: "MatchedStatus", title: "Matched Status", width: 100, filterable: false }

                    ]
                });

            }

            function testTemplating() {
                $(_element).html('<button id="btnImage" style="width:100px; height:20px;">' +
                            '</button></br></br>');

                var currentTemplate = _.template('<img src="<%= currentPath %>images/head-icon.png" />');

                var btnImage = document.getElementById('btnImage');

                btnImage.innerHTML += currentTemplate({ currentPath: require.toUrl('./') });
            }

            function applyUpDownColorRule(data, dataSource) {
                var grid = $(_element).data("kendoGrid");

                if (typeof grid === 'undefined' || typeof grid.dataSource === 'undefined') {
                    return;
                }

                var dataItem = grid.dataSource.get(data.OrderID);

                if (typeof dataItem === 'undefined') {
                    return;
                }

                var previousValue = dataItem.Amount;
                var newValue = data.Amount;

                var previousValueNotional = dataItem.Notional;
                var newValueNotional = data.Notional;
				
				dataItem.Amount = data.Amount;
                //update datasource with new value
                dataSource.pushUpdate(data);

                var availableColumns = grid.columns;

                var updatedColumnIndex = 0;
                var updatedNotionalColumnIndex = 0;

                for (var j = 0; j < availableColumns.length; j = j + 1) {
                    if (availableColumns[j].field == "Amount") {
                        break;
                    }
                    updatedColumnIndex = updatedColumnIndex + 1;
                }

                for (var i = 0; i < availableColumns.length; i = i + 1) {
                    if (availableColumns[i].field == "Notional") {
                        break;
                    }
                    updatedNotionalColumnIndex = updatedNotionalColumnIndex + 1;
                }

                var row = grid.tbody.find("tr[data-uid='" + dataItem.uid + "']");

                if (previousValue !== newValue) {

                    var cell = row.children().eq(updatedColumnIndex);
                    cell.addClass(addUpDownRule(previousValue, newValue));
                }
				/*
                if (previousValueNotional !== newValueNotional) {

                    var cellNotional = row.children().eq(updatedNotionalColumnIndex);
                    cellNotional.addClass(addUpDownRule(previousValueNotional, newValueNotional));
                }*/
            }

            function addUpDownRule(previousValue, newValue) {
                if (previousValue < newValue) {
                    return "up";
                }
                else {
                    return "down";
                }
            }

            return {
                init: init,
                render: render
            };
        };

        return moduleInstance;
    });