﻿"use strict";

define(function (require) {

    var moduleInstance = function () {

        var _context, _element, _eventSource;

        function init(context, settings) {

            _context = context;
        }

        function render(element) {

            _element = $(element);

             //_element.innerHTML = '<object type="type/html" data="openfinModule/childWindow.html" ></object>';
var url = require.toUrl('./openfinModule/childWindow.html');
            _element.html( "<iframe src='"+url+"'> </iframe>");

        }

        return {
            init: init,
            render: render
        };
    };

    return moduleInstance;
});