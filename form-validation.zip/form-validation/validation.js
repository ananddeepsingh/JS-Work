;(function(window, undefined) {
  
	window.Validator = {
		
		constructor: function(form, config) {
		  this._elForm = form;
		  this._els = config.fields || {};
		  
		  this.init();
		},
		
		init: function() {
		  this.addFormListener();
		},
		
		addFormListener: function() {
			var formSelector = this._elForm
			  , elForm = document.querySelector(formSelector);
			  
			  elForm.addEventListener('submit', this.validate.bind(this), false);
		},
		
		validate: function(e) {
		  var elFields = this._els;
		  
		  for ( var field in elFields ) {
			var el = document.querySelector(field)
			  , elVal = el.value;
			  
			if ( elFields[field].require || elVal === '' || elVal.length > elFields[field].maxlength ) {
				el.classList.add('invalid');
			}else{
				el.classList.add('valid');
			}
		  }
		  
		  e.preventDefault();
		}
	  
	}
  
})(window, undefined);

