Thanks for downloading BounceGame.

Upload all files to your web server, and run index.htm in your web browser.

NOTES:

If you change the gameHeight or gameWidth be sure to change the height, and width attributes of iframe.game in the style of index.htm

MY LINK:

You can remove my link in index.htm, BUT PLEASE find another way to support my work.

Always send hits thru http://scottconnell.com I will redirect traffic to my current host.

Thanks, Scott
